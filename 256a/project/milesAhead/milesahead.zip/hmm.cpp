//  hmm.cpp
//  Abstraction for Hidden Markov Models

//  Created by Mayank Sanganeria 11-23-11

#include "hmm.h"
#include <iostream>

