#ifndef HMM_INCLUDED
#define HMM_INCLUDED

//  hmm.h
//  Abstraction for Hidden Markov Models
// 
//  Created by Mayank Sanganeria 11-23-11

#include <vector>
#include "MidiEvent.h"

using namespace std;

class hmm {
public:

private:
    vector < vector < > >
    int size;


};
#endif