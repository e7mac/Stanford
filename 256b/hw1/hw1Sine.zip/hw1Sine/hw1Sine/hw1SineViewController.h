//
//  hw1SineViewController.h
//  hw1Sine
//
//  Created by Mayank Sanganeria on 1/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WaveView.h"

@interface hw1SineViewController : UIViewController <WaveViewProtocol>

@property (weak, atomic) IBOutlet WaveView *waveView;

- (IBAction)toggleButton:(id)sender;

@end
