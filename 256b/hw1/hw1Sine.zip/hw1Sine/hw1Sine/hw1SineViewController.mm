//
//  hw1SineViewController.m
//  hw1Sine
//
//  Created by Mayank Sanganeria on 1/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "hw1SineViewController.h"
#import "mo_audio.h"
#import "mo_touch.h"
#import "mo_accel.h"
#import "Envelope.h"
#import <vector>

#define SRATE 44100
#define FRAMESIZE 128
#define NUMCHANNELS 2

// global variables
double g_fc = 800.0;
double g_fOffset = 0.0;
bool g_on = true    ;
float myGain = 0.5;
float g_bufferData[512];
stk::Envelope *g_envelope;



#pragma mark - Callbacks
//-------------------------Callback functions------------------------------

void sineCallback( Float32 * buffer, UInt32 frameSize, void * userData )
{
    static float phase = g_fc/SRATE;    
    for(int i=0; i < frameSize; i++)
    {
        float env = g_envelope->tick();
        buffer[2*i] = buffer[2*i +1] = myGain*sin(2.0*M_PI*phase)*env;
        g_bufferData[i] = 10*buffer[2*i];
        phase += (g_fc + g_fOffset)/(SRATE*1.0);
        
        if(phase > 1.0f)
            phase -= 1.0f;
    }
}

void audioCallback( Float32 * buffer, UInt32 frameSize, void * userData )
{
    sineCallback( buffer, frameSize, userData);
}


void accelCallback( double x, double y, double z, void * data )
{
    // NSLog(@"Accel!");        
    g_fc = 440.0 + x*100;
    WaveView *wv=(__bridge WaveView *)data;
    [wv setNeedsDisplay];
    //NSLog([[NSNumber numberWithFloat:g_envelope->tick()] stringValue]);
    
}

void touchCallback( NSSet * touches, UIView * view, const std::vector<MoTouchTrack> & touchPts, void * data)
{
    // NSLog(@"Touch!!!");        
    UIView * vview = (__bridge UIView *)data;
    long count = [touches count];
    // If there's one touch
    if(count==1)
    {
        for( UITouch * touch in touches)
        {
            CGPoint point = [touch locationInView:vview];
            g_fOffset = point.x;
            NSLog(@"%f %f", point.x, point.y);
        }
    } 
}




@implementation hw1SineViewController

@synthesize waveView = _waveView;


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    g_envelope = new stk::Envelope;
    g_envelope->setTime(0.05);
    g_envelope->setValue(1.0);
    // log
    NSLog( @"starting real-time audio..." );
    // init the audio layer
    bool result = MoAudio::init( SRATE, 64, 2 );
    if( !result )
    {
        // something went wrong
        NSLog( @"cannot initialize real-time audio!" );
        // bail out
        return;
    }
    // start the audio layer, registering a callback method
    result = MoAudio::start( audioCallback,NULL);
    if( !result )
    {
        // something went wrong
        NSLog( @"cannot start real-time audio!" );
        // bail out
        return;
    }
    //add acceleration and touch callbacks
    MoAccel::addCallback( accelCallback,  (__bridge void *)self.waveView );
    MoTouch::addCallback( touchCallback, NULL);
    self.waveView.dataSource = self;


    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (IBAction)toggleButton:(id)sender {
    g_on = !g_on;
    if (g_on)
        g_envelope->keyOn();
    else 
        g_envelope->keyOff();
    [self.waveView setNeedsDisplay];
}

-(NSArray *)getWaveData:(WaveView *)wavev {
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:128];
    for (int i=0;i<128;i++)
    {
        [array addObject:[NSNumber numberWithFloat:g_bufferData[i]]];
    }
    return array;
}

@end
