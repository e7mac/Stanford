//DelayLine class
//author: Mayank Sanganeria


class DelayLine
{
public:
	DelayLine(int max_length,int delay);
	DelayLine();
	~DelayLine();
	void resize(int max_length);
	float read();
	void write(float f);
	void advanceReadHead();
    void setDelayLength(int);
    void clear();
    void setFeedback(float f);
    
private:
	float *buffer;
    float feedback;
    int delay;
    int length;
	int readHead;
	int writeHead;
};