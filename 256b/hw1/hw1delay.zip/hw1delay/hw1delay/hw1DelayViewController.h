//
//  hw1DelayViewController.h
//  hw1delay
//
//  Created by Mayank Sanganeria on 1/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WaveView.h"

@interface hw1DelayViewController : UIViewController <WaveViewProtocol>
@property (weak, nonatomic) IBOutlet UILabel *delayFeedback;
- (IBAction)setFeedback:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *delayLength;
@property (weak, nonatomic) IBOutlet WaveView *waveView;
@end
