//
//  hw1DelayViewController.m
//  hw1delay
//
//  Created by Mayank Sanganeria on 1/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "hw1DelayViewController.h"

#import "mo_audio.h"
#import "mo_touch.h"
#import "mo_accel.h"
#import "DelayLine.h"
#import "Envelope.h"


#define SRATE 44100
#define FRAMESIZE 128
#define NUMCHANNELS 2


stk::Envelope *g_envelope;

double g_fc = 440.0;
double g_fOffset = 0.0;
bool g_on = false;
float myGain = 0.5;


DelayLine g_delay(100000,700);
float g_bufferdata[512];

void accelCallback( double x, double y, double z, void * data )
{
    // NSLog(@"Accel!");        
    g_fc = 440.0 + x*100;
    WaveView *wv = (__bridge WaveView *)data;
    [wv setNeedsDisplay];
}

// the audio callback
void audioCallback( Float32 * buffer, UInt32 frameSize, void * userData )
{
    float val;
	for ( int i = 0; i < frameSize; i++ )
	{
		g_delay.write(buffer[2*i]);
        g_bufferdata[i] = buffer[2*i];
        val = g_delay.read();
        g_envelope->setTarget(val);
        buffer[2*i] = buffer[2*i+1] = g_envelope->tick();
        g_delay.advanceReadHead();
	}
}

void touchCallback( NSSet * touches, UIView * view, const std::vector<MoTouchTrack> & touchPts, void * data)
{
    // NSLog(@"Touch!!!");        
    UIView * vview = (__bridge UIView *)data;
    long count = [touches count];
    float x_diff=0,y_diff=0;

    if(count==2)
    {
        for( UITouch * touch in touches)
        {
            
            CGPoint point = [touch locationInView:vview];
            g_fOffset = point.x;
            x_diff = -x_diff+point.x;
            y_diff = -y_diff+point.y;
        }
        float dist = powf(x_diff*x_diff + y_diff*y_diff,0.5);
        NSLog(@"%f", dist);
        g_delay.setDelayLength(dist*15);
        UILabel * delayLength = (__bridge UILabel *)data;
        delayLength.text = [[NSNumber numberWithFloat:dist*15] stringValue];;
        
    }
}



@implementation hw1DelayViewController
@synthesize waveView = _waveView;
@synthesize delayLength = _delayLength;
@synthesize delayFeedback = _delayFeedback;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}


#pragma mark - View lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    g_envelope = new stk::Envelope;
    g_envelope->setTime(0.005);
    g_envelope->setValue(1);
    g_delay.setFeedback(0.5);
    // log
    NSLog( @"starting real-time audio..." );
    // init the audio layer
    bool result = MoAudio::init( SRATE, 64, 2 );
    if( !result )
    {
        // something went wrong
        NSLog( @"cannot initialize real-time audio!" );
        // bail out
        return;
    }
    // start the audio layer, registering a callback method
    result = MoAudio::start( audioCallback, NULL );
    if( !result )
    {
        // something went wrong
        NSLog( @"cannot start real-time audio!" );
        // bail out
        return;
    }
    self.waveView.dataSource = self;
    MoAccel::addCallback( accelCallback, (__bridge void*)self.waveView);
    
    MoTouch::addCallback( touchCallback, (__bridge void *)self.delayLength);
    
}

- (void)viewDidUnload
{
    [self setDelayFeedback:nil];
    [self setDelayLength:nil];
    [self setWaveView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (IBAction)setFeedback:(id)sender {
    g_delay.setFeedback([(UISlider *)sender value]);
    self.delayFeedback.text = [[NSNumber numberWithFloat:[(UISlider *)sender value]] stringValue];
}

-(NSArray *)getWaveData:(WaveView *)wavev {
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:128];
    for (int i=0;i<128;i++)
    {
        [array addObject:[NSNumber numberWithFloat:g_bufferdata[i]]];
    }
    return array;
}


@end
