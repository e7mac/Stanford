//
//  Projectile.h
//
//  Created by Mayank Sanganeria on 1/19/11.
//  Copyright 2011 Stanford University. All rights reserved.
//

#include "mo_gfx.h"

class Projectile
{
public:
    Projectile();
    Projectile(float, float);
    void setVel(float, float);
    void setAcc(float, float);
    void getAcc(float&, float&);
    void drawProjectile(GLuint text[]);
    void update(float,bool &wall);
    void setBounds(float, float);
    void setPos(float , float);
    static void collisionDetection(Projectile[], int num,bool &collision, float &impact);
    static void drawCircle(float,float,float radius, int color);
    static void drawSphere(float,float,float radius, int color);
    static GLuint textures[1];
private:
    float radius;
    float pos_x,pos_y;
    float vel_x,vel_y;
    float acc_x,acc_y;
    float bound_x,bound_y;
    
};