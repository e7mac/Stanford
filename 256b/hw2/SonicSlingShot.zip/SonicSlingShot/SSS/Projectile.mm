//
//  Projectile.m
//
//  Created by Mayank Sanganeria on 1/19/11.
//  Copyright 2011 Stanford University. All rights reserved.
//

#include "Projectile.h"
#include "mo_gfx.h"

#define PI 3.142

Projectile::Projectile()
{
    radius = 20;
    pos_x=0;
    pos_y=0;
    vel_x=0;
    vel_y=0;
    acc_x=0;
    acc_y=0;
    bound_x = 0;
    bound_y = 0;
    
}

Projectile::Projectile(float x, float y)
{
    radius = 20;
    pos_x=x;
    pos_y=y;
    vel_x=0;
    vel_y=0;
    acc_x=0;
    acc_y=0;
    bound_x = 0;
    bound_y = 0;
    if (pos_x<=radius) pos_x = 2*radius;
    if (pos_y<=radius) pos_y = 2*radius;
    
}
void Projectile::setVel(float vx, float vy)
{
    vel_x=vx;
    vel_y=vy;
}
void Projectile::setAcc(float ax, float ay)
{
    acc_x=ax;
    acc_y=ay;
}
void Projectile::getAcc(float& ax, float& ay)
{
    ax=acc_x;
    ay=acc_y;
}


void Projectile::drawProjectile(GLuint texture[])
{
    
    //actual drawing
    
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    
    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    
    GLfloat halfWidth = radius;
    GLfloat squareVertices[4*3] = {
        pos_x - halfWidth, pos_y + halfWidth, -0.0,
        pos_x + halfWidth, pos_y + halfWidth, -0.0,
        pos_x - halfWidth, pos_y - halfWidth, -0.0,
        pos_x + halfWidth, pos_y - halfWidth, -0.0
    };
    
    static GLfloat squareTexCoords[4*2] = {
        0.0, 1.0,
        1.0, 1.0,
        0.0, 0.0,
        1.0, 0.0
    };
    
    static const GLfloat normals[4*3] = {
        0.0, 0.0, 1.0,
        0.0, 0.0, 1.0,
        0.0, 0.0, 1.0,
        0.0, 0.0, 1.0
    };
    
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    
    glBindTexture(GL_TEXTURE_2D, texture[0]);
    glVertexPointer(3, GL_FLOAT, 0, squareVertices);
    glNormalPointer(GL_FLOAT, 0, normals);
    glTexCoordPointer(2, GL_FLOAT, 0, squareTexCoords);
    
    
    // glDrawArrays(GL_TRIANGLE_FAN, 0, 360);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    
    // glDeleteTextures(1, &_textures[0]);
    
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    
    glDisable(GL_TEXTURE_2D);
    
}
 
void Projectile::update(float time, bool &wall)
{
    
    pos_x = pos_x + time*vel_x + 0.5*time*time*acc_x;
    pos_y = pos_y + time*vel_y + 0.5*time*time*acc_y;
    vel_x = vel_x + time*acc_x;
    vel_y = vel_y + time*acc_y;
    if (pos_x - radius <= 0 || pos_x + radius >= bound_x)
    {
        vel_x = -vel_x;
        wall = true;
    }
    if (pos_y - radius<= 0 || pos_y +radius >= bound_y)
    {
        vel_y = -vel_y;
        wall=true;
    }
    if (pos_x>=bound_x-radius) pos_x = bound_x-radius;
    if (pos_y>=bound_y-radius) pos_y = bound_y-radius;
    if (pos_x<=radius) pos_x = radius;
    if (pos_y<=radius) pos_y = radius;

    
}

void Projectile::setPos(float x,float y)
{
    pos_x = x;
    pos_y = y;
    if (pos_x>=bound_x-radius) pos_x = bound_x-radius;
    if (pos_y>=bound_y-radius) pos_y = bound_y-radius;
    if (pos_x<=radius) pos_x = radius;
    if (pos_y<=radius) pos_y = radius;


}

void Projectile::setBounds(float x, float y)
{
    bound_x = x;
    bound_y = y;
    
}

void Projectile::collisionDetection(Projectile a[],int num, bool &collision, float &impact)
{
    for (int i=0;i<num;i++)
    {
        for (int j=i+1;j<num;j++)
        {
            if ((fabs(a[i].pos_x-a[j].pos_x)<a[i].radius+a[j].radius)&&(fabs(a[i].pos_y-a[j].pos_y)<a[i].radius+a[j].radius))
            { 
                collision = true;
                float theta = atanf((a[i].pos_y - a[j].pos_y)/(a[i].pos_x - a[j].pos_x));
                float u1x,u1y,u2x,u2y;
                u1x = a[i].vel_x;
                u1y = a[i].vel_y;
                u2x = a[j].vel_x;
                u2y = a[j].vel_y;
                float u1t,u1r,u2t,u2r;
                u1t = u1x*cosf(theta)+u1y*sinf(theta);
                u1r = -u1x*sinf(theta)+u1y*cosf(theta);
                u2t = u2x*cosf(theta)+u2y*sinf(theta);
                u2r = -u2x*sinf(theta)+u2y*cosf(theta);
                float v1t,v1r,v2t,v2r;
                v1t = u2t;
                v1r = u1r;
                v2t = u1t;
                v2r = u2r;
                impact = fabsf(v1t-v2t);
                float v1x,v1y,v2x,v2y;
                v1x = v1t*cosf(theta) - v1r*sinf(theta);
                v1y = v1t*sinf(theta) + v1r*cosf(theta);
                v2x = v2t*cosf(theta) - v2r*sinf(theta);                
                v2y = v2t*sinf(theta) + v2r*cosf(theta);
                a[i].vel_x = v1x;
                a[i].vel_y = v1y;
                a[j].vel_x = v2x;
                a[j].vel_y = v2y;
                float midx = (a[i].pos_x+a[j].pos_x)/2;
                float midy = (a[j].pos_y+a[i].pos_y)/2;
                drawSphere(midx, midy, 50, 1);

            }
        }
        
    }
}


void Projectile::drawCircle(float x,float y,float radius, int color)
{
    // draw straight line from v0 to v1
    GLfloat circleVertices[50];
    for (int i=0;i<49;i+=2)
    {
        circleVertices[i]=x+radius*cosf(i/(2*PI));
        circleVertices[i+1]=y+radius*sinf(i/(2*PI));
    }
    // enable
    glEnableClientState( GL_VERTEX_ARRAY );	
    //dist
    // push
    glPushMatrix();
    // vertex
    glVertexPointer(2, GL_FLOAT, 0, circleVertices);
    // color
    glColor4f( 1.0f, 1.0f, 1.0f, 1.0f );
    // draw!
    glDrawArrays( GL_POINTS, 0, 25 );
    // pop
    glPopMatrix();
    
}

void Projectile::drawSphere(float x,float y,float radius, int color)
{
    for (int i=0;i<50;i++)
        drawCircle(x,y,radius*i/50.0,1);
}
