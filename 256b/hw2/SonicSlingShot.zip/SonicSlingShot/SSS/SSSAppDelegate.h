//
//  SSSAppDelegate.h
//  SSS
//
//  Created by Ge Wang on 1/23/12.
//  Copyright (c) 2012 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SSSViewController;

@interface SSSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) SSSViewController *viewController;

@end
