//
//  SlingShot.h
//
//  Created by Mayank Sanganeria on 01.25.2012.
//  Copyright 2011 Stanford University. All rights reserved.
//

class SlingShot
{
public:
    SlingShot(float,float,float,float);
    void drawBand();
    void stretchBand(float,float, float&, float&);
    void deleteBand();
    float angle();
    void center(float &,float &);
    void checkVelDirection(float,float,float &);
private:
    float distance(float,float,float,float);
    float x0,y0,x1,y1,xc,yc;
};