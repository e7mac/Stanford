//
//  SlingShot.h
//
//  Created by Mayank Sanganeria on 01.25.2012.
//  Copyright 2011 Stanford University. All rights reserved.
//
#include "SlingShot.h"
#include "mo_gfx.h"


float SlingShot::distance(float x1,float y1,float x2,float y2)
{
    return powf(((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)),0.5);
}

SlingShot::SlingShot(float xw0,float yw0,float xw1,float yw1)
{
    x0=xw0;
    y0=yw0;
    x1=xw1;
    y1=yw1;
    center(xc, yc);
}

void SlingShot::drawBand()
{
    // draw straight line from v0 to v1
    GLfloat lineVertices[6] = { x0, y0, xc,yc,x1, y1 };
    // enable
    glEnableClientState( GL_VERTEX_ARRAY );	
    //dist
    GLfloat dist = powf(((x0-x1)*(x0-x1)+(y0-y1)*(y0-y1)),0.5);
    // push
    glPushMatrix();
    // vertex
    glVertexPointer(2, GL_FLOAT, 0, lineVertices);
    // color
    glColor4f( 1.0f, 1.0f, 1.0f, 0.5f );
    // width
    glLineWidth(500 * 1./(1+dist));
    // draw!
    glDrawArrays( GL_LINE_STRIP, 0, 3 );
    // pop
    glPopMatrix();
    float centx,centy;
    center(centx,centy);
    if (fabs(centx-xc)<1)
        xc=centx;
    else if (centx>xc)
        xc += fabs(centx-xc)/40;
    else if (centx<xc)
    xc -= fabs(centx-xc)/40;
    if (fabs(centy-yc)<1)
        yc=centy;
    else if (centy>yc)
        yc +=fabs(centy-yc)/40;
    else if (centy<yc)
        yc -= fabs(centy-yc)/40;;

    
}

void SlingShot::stretchBand(float x,float y, float &energy, float &alpha)
{
    // draw straight line from v0 to v1
    GLfloat lineVertices[6] = { x0, y0, x, y, x1, y1 };
    // enable
    glEnableClientState( GL_VERTEX_ARRAY );	
    //dist
    GLfloat dist = distance(x0,y0,x1,y1);
    //dist
    GLfloat newDist = distance(x,y,x0,y0) + distance(x,y,x1,y1);
    GLfloat distStretch = newDist - dist;
    // push
    glPushMatrix();
    // vertex
    glVertexPointer(2, GL_FLOAT, 0, lineVertices);
    // color
    glColor4f( 1.0f, 1.0f, 1.0f, 1.0f );
    // width
    glLineWidth(500 * 1./(1+dist));
    // draw!
    glDrawArrays( GL_LINE_STRIP, 0, 3 );
    // pop
    glPopMatrix();
    float k = 5;
    energy = 0.5*k*distStretch*distStretch;

    //direction
    float cent_x,cent_y;
    center(cent_x, cent_y);
    alpha = atanf((y-cent_y)/(x-cent_x));
    if ((cent_y>y && sinf(alpha)<0)||(cent_y<y && sinf(alpha)>0))
        alpha = -alpha;
    if ((cent_x>x && cosf(alpha)<0)||(cent_x<x && cosf(alpha)>0))
        alpha = +3.1415925-alpha;
    
    xc=x;
    yc=y;
}
void SlingShot::deleteBand()
{
    
}

float SlingShot::angle()
{
    return atanf(-(y0-y1)/(x0-x1));
}

void SlingShot::center(float& ret_x, float& ret_y)
{
    ret_x = 0.5*(x0+x1);
    ret_y = 0.5*(y0+y1);
}