//-----------------------------------------------------------------------------
//  name: renderer.m
//  desc: graphics + audio module for HellOGLES
//
//  author: created by Ge Wang
//  date: winter 2011
//-----------------------------------------------------------------------------
#ifndef __RENDERER_H__
#define __RENDERER_H_

#include "mo_gfx.h"

// initialize
bool yayInit();
// set dimensions of rendering surface
void yaySetDims( GLint width, GLint height );
// render
void yayRender();
// cleanup
void yayCleanup();

//-----------------------------------------------------------------------------
// name: class Entity
// desc: abstraction for a entity
//-----------------------------------------------------------------------------
class Entity
{
public:
    Entity() : alpha( 1.0f ) { }
    virtual void render() { /* default: do nothing */ }
    
public:
    // location
    Vector3D loc;
    // orientation
    Vector3D ori;
    // scaling
    Vector3D sca;
    // color
    Vector3D col;
    // alpha
    GLfloat alpha;
    // velocity
    Vector3D vel;
};


//-----------------------------------------------------------------------------
// name: class TouchEntity
// desc: touch entity
//-----------------------------------------------------------------------------
class TouchEntity : public Entity
{
public:
    TouchEntity() : active(false), touch_ref(NULL) { }
    virtual void render();
    
public:
    GLboolean active;
    UITouch * touch_ref;
};
#endif
