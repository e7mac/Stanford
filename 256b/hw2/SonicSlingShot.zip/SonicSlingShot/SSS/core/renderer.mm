//-----------------------------------------------------------------------------
//  name: renderer.mm
//  name: graphics + audio for HellOGLES
//
//  author: Ge Wang
//  date: winter 2011
//-----------------------------------------------------------------------------
#import "renderer.h"
#import "mo_audio.h"
#import "mo_gfx.h"
#import "mo_touch.h"
#import "SlingShot.h"
#import "Projectile.h"
#import "mo_accel.h"
#import "Stk.h"
#import "StifKarp.h"
#import "Mandolin.h"


// defines
#define SRATE 24000
#define FRAMESIZE 512
#define NUM_CHANNELS 2
#define MAX_TOUCHES 5
// global
SAMPLE g_width = 2.5;
GLint g_GfxWidth = 320;
GLint g_GfxHeight = 480;

// buffer
SAMPLE g_vertices[FRAMESIZE*4];
// last frame size
UInt32 g_lastNumFrames = 0;

//touch entities
TouchEntity *g_touches[MAX_TOUCHES];
//num of touches
UInt32 g_numActiveTouches = 0;
bool new_proj;
int g_numProjectiles=0;
bool g_band = false;
SlingShot g_ss(0,0,0,0);
Projectile g_proj[100];
bool collision=false,wall_collision=false;;


//audio things
stk::StifKarp *ks;
stk::StifKarp *mandolin[3];
GLuint g_texture[1];

void touch_callback( NSSet * touches, UIView * view, const std::vector<MoTouchTrack> & tracks, void * data);
float closestFreq(float f)
{
    float note_freqs[]={110.00,123.47,130.81,146.83,164.81,174.61,196.00,220.00,246.94,261.63,293.66,329.63,349.23,392.00,440.00,493.88,523.25,587.33,659.26,698.46,783.99,880.00,987.77,1046.50,1174.66,1318.51,1396.91,1567.98,1760.00};

    for (int i=0;i<28;i++)
    {
        if (f<=note_freqs[i]) {
//            NSLog(@"%f",note_freqs[i]);            
            return note_freqs[i];
        }
    }
    return note_freqs[28];
}

//-----------------------------------------------------------------------------
// name: repositionBand()
// desc: repositions the slingshot
//-----------------------------------------------------------------------------
void repositionBand()
{
    // check
    if( g_numActiveTouches < 2 ) return;
    
    // sanity check
    assert( g_touches[0]->active && g_touches[1]->active );
    
    float x0 = g_touches[0]->loc.x;
    float y0 = g_touches[0]->loc.y;
    float x1 = g_touches[1]->loc.x;
    float y1 = g_touches[1]->loc.y;
    
    SlingShot ss(x0,y0,x1,y1);
    g_ss = ss;
    g_band = true;

}


void accelCallback( double x, double y, double z, void * data )
{
    //NSLog(@"Accel! %f %f %f",x,y,z);        
    for (int i=0;i<g_numProjectiles;i++)
        g_proj[i].setAcc(-20*y, 20*x);
}


//-----------------------------------------------------------------------------
// name: audio_callback()
// desc: audio callback, yeah
//-----------------------------------------------------------------------------
void audio_callback( Float32 * buffer, UInt32 numFrames, void * userData )
{
    if (collision)
    {
        ks->pluck(1);
        collision = false;
    }
    if (wall_collision)
    {
        for (int i=0;i<3;i++)
            mandolin[i]->pluck(0.1);
        wall_collision = false;
    }
    
    
    
    for ( int i = 0; i < numFrames; i++ )
    {
        float tmp=ks->tick()+mandolin[0]->tick()+mandolin[1]->tick()+mandolin[2]->tick();
        {
            buffer[2*i] = buffer[2*i + 1] = 0.1*tmp;
        }
    }
    
//    g_lastNumFrames = numFrames;
//    SAMPLE x = 0;
//    SAMPLE inc = g_width / numFrames;
//    float total=0;
//    for( int i = 0; i < numFrames; i++ )
//    {
//        // x coordinate
//        g_vertices[2*i] = x; x += inc;
//        // y coordinate
//        g_vertices[2*i+1] = buffer[2*i] * 3;
//        total+= powf(buffer[2*i]*buffer[2*i],0.5);
//        // zero
//        buffer[2*i] = buffer[2*i+1] = 0;
//    }
//    float ax,ay;
////    g_proj.getAcc(ax,ay);
////    g_proj.setAcc(ax+total/12,ay);
}




//-----------------------------------------------------------------------------
// name: setDims()
// desc: set dimension
//-----------------------------------------------------------------------------
void yaySetDims( GLint width, GLint height )
{
    g_GfxWidth = width;
    g_GfxHeight = height;
}




//-----------------------------------------------------------------------------
// name: init()
// desc: initialize graphics and sound
//-----------------------------------------------------------------------------
bool yayInit()
{
    
    
    //setup audio
    ks = new stk::StifKarp(10);
    ks->setFrequency(440);
    for (int i=0;i<3;i++)
        mandolin[i] = new stk::StifKarp(100 );
        
    mandolin[0]->setFrequency(110);
    mandolin[0]->setFrequency(130.81);
    mandolin[0]->setFrequency(164.81);

    
    // init touch
    MoTouch::addCallback(touch_callback, NULL);
    MoAccel::addCallback( accelCallback, NULL);

    for (int i=0;i<MAX_TOUCHES;i++)
    {
        g_touches[i] = new TouchEntity();
        g_touches[i]->col.set(1,1,1);
    }
    // init
    bool result = MoAudio::init( SRATE, FRAMESIZE, NUM_CHANNELS );
    if( !result )
    {
        // do not do this:
        int * p = 0;
        *p = 0;
    }
    // start
    result = MoAudio::start( audio_callback, NULL );
    if( !result )
    {
        // do not do this:
        int * p = 0;
        *p = 0;
    }
    glGenTextures(1, &g_texture[0]);
    glBindTexture(GL_TEXTURE_2D, g_texture[0]);
    MoGfx::loadTexture(@"ball", @"png");

    return true;
}




//-----------------------------------------------------------------------------
// name: cleanup()
// desc: clean up
//-----------------------------------------------------------------------------
void yayCleanup()
{
    delete ks;

}


// name: drawTouchEntities()
// desc: renders each of the touch entities
//-----------------------------------------------------------------------------
void drawTouchEntities()
{
    for( int i = 0; i < MAX_TOUCHES; i++ )
    {
        // check active
        if( g_touches[i]->active )
        {
            // push
            glPushMatrix();
            // translate
            glTranslatef( g_touches[i]->loc.x, g_touches[i]->loc.y, g_touches[i]->loc.z );
            // render
            g_touches[i]->render();
            // pop
            glPopMatrix();
        }
    }	
}


//-----------------------------------------------------------------------------
// name: render()
// desc: render next frame of graphics
//-----------------------------------------------------------------------------
void yayRender()
{
    // set to ortho
    MoGfx::ortho( 320, 480, 1 );
    
    // set clear color
    glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
    // clear it
    glClear( GL_COLOR_BUFFER_BIT );

    
    //draw slingshot
    repositionBand();

    static float x,y,energy,alpha;
    if (( g_numActiveTouches == 1) && g_band)
    {
        x=g_touches[0]->loc.x;
        y=g_touches[0]->loc.y;
        g_ss.stretchBand(x,y,energy,alpha);
        new_proj = true;
    }
    
    else
    {
        g_ss.drawBand();
    } 

    if (( g_numActiveTouches == 0) && new_proj)
    {
        new_proj=false;
        if (g_numProjectiles<10)
        {

            g_proj[g_numProjectiles].setBounds(480,320);
            g_proj[g_numProjectiles].setPos(x,y);
            float vel = powf(0.1*energy,0.5);
            g_proj[g_numProjectiles].setVel(vel*cosf(alpha),vel*sinf(alpha));
            g_numProjectiles++;
        }
        else
            g_numProjectiles = 0;
    }
    for (int i=0;i<g_numProjectiles;i++)
    {
        g_proj[i].drawProjectile(g_texture);
        g_proj[i].update(0.5,wall_collision);
    }
    static float impact;
    Projectile::collisionDetection(g_proj, g_numProjectiles, collision, impact);
    if (impact>1)
    {
        float freq = impact*10.0;
        float a=closestFreq(freq);
        ks->setFrequency(a);
        impact = 0;
    }


    
}

//----------------------------------------------------------------------------
// name: render()
// desc: draw a touch entity
//----------------------------------------------------------------------------
void TouchEntity::render()
{
    static const GLfloat half_width = 30;
    static const GLfloat squareVertices[] = {
        -half_width, -half_width,
        half_width, -half_width,
        -half_width, half_width,
        half_width, half_width,
    };
    
    // enable
    glEnableClientState( GL_VERTEX_ARRAY );	
    
    glPushMatrix();
    
    // color
    glColor4f( col.x, col.y, col.z, alpha );
    // vertex
    glVertexPointer( 2, GL_FLOAT, 0, squareVertices );
    
    // triangle strip
    glDrawArrays( GL_TRIANGLE_STRIP, 0, 4 );
    
    glPopMatrix();
    
    // disable
    glDisableClientState( GL_VERTEX_ARRAY );
}


//-----------------------------------------------------------------------------
// name: touch_callback()
// desc: touch callback function
//-----------------------------------------------------------------------------
void touch_callback( NSSet * touches, UIView * view, const std::vector<MoTouchTrack> & tracks, void * data)
{
    // iterate over touch points
    CGPoint location;
    for( UITouch * touch in touches )
    {
        // get the location
        location = [touch locationInView:nil];
        
        // transform: to make landscape
        double temp = location.x;
        location.x = location.y;
        location.y = temp;
        
        // NSLog( @"touch: %f, %f,", location.x, location.y );
        
        if( touch.phase == UITouchPhaseBegan )
        {
            // find idle touch entity
            TouchEntity * entity = NULL;
            for( int i = 0; i < MAX_TOUCHES; i++ )
            {
                // in case touch already active
                if( g_touches[i]->touch_ref == touch )
                    break;
                
                // find the next non-active touch
                if( !g_touches[i]->active )
                {
                    entity = g_touches[i];
                    break;
                }
            }
            
            // sanity check
            if( entity != NULL )
            {
                // set
                entity->active = true;
                entity->touch_ref = touch;
                entity->loc.x = location.x;
                entity->loc.y = location.y;                
                // count
                g_numActiveTouches++;
                // log it
//                NSLog( @"active touches: %d", g_numActiveTouches );
            }
        }
        else if( touch.phase == UITouchPhaseMoved )
        {
            for( int i = 0; i < MAX_TOUCHES; i++ )
            {
                if( g_touches[i]->touch_ref == touch )
                {
                    g_touches[i]->loc.x = location.x;
                    g_touches[i]->loc.y = location.y;
                    break;
                }
            }
        }
        else if( (touch.phase == UITouchPhaseEnded) || (touch.phase == UITouchPhaseCancelled) )
        {
            for( int i = 0; i < MAX_TOUCHES; i++ )
            {
                if( g_touches[i]->touch_ref == touch )
                {
                    // set
                    g_touches[i]->active = false;
                    g_touches[i]->touch_ref = NULL;
                    
                    // pack active touches
                    for( int j = i+1; j < MAX_TOUCHES; j++ )
                    {
                        if( g_touches[j]->active )
                        {
                            // swap
                            TouchEntity * swap = g_touches[i];
                            g_touches[i] = g_touches[j];
                            g_touches[j] = swap;
                            // dangerous: advance i
                            i = j;
                        }
                    }
                    
                    // count
                    g_numActiveTouches--;
                    // log
//                    NSLog( @"active touches: %d", g_numActiveTouches );
                    
                    break;
                }
            }
        }
    }
}

