#include "DelayLine.h"

DelayLine::DelayLine(const int max_length, int w_delay)
{
	buffer = new float[max_length];
    readHead = 0;
    writeHead = w_delay;
    delay = w_delay;
    length = max_length;
    feedback=0;
    clear();
}


void DelayLine::clear()
{
    for (int j = 0; j < length; j++) {
		buffer[j] = 0;
	}

}

DelayLine::DelayLine()
{
	buffer = new float[480000];
    readHead = 0;
    writeHead = 0;
    delay = 0;
    length = 480000;
    feedback=0;
    clear();
}
DelayLine::~DelayLine()
{
	delete[] buffer;
}


void DelayLine::setFeedback(float f)
{
    feedback = f;
}

void DelayLine::resize(const int max_length)
{
    int smaller_length;
    smaller_length = max_length>length ? length : max_length;
	float *new_buff = new float[max_length];
    for (int i=0;i<smaller_length;i++)
        new_buff[i] = buffer[i];
    delete[] buffer;
    buffer = new_buff;
	
}

int DelayLine::size()
{
    return (writeHead-readHead)%length;
}



float DelayLine::read()
{
	return buffer[readHead];
}

void DelayLine::advanceReadHead()
{
    readHead = (readHead+1)%length;
}

void DelayLine::setDelayLength(int l)
{
    delay = l;
    if (delay>length)
        delay = length;
    writeHead = (readHead + delay)%length;
}


void DelayLine::write(float f)
{
	buffer[writeHead] = f + feedback*read();
    writeHead = (writeHead+1)%length;
}