//
//  Soundshape.h
//
//  Created by Mayank Sanganeria on 02/06/2012.
//  Copyright 2011 Stanford University. All rights reserved.
//

#include <vector>
#include <queue>
#import <GLKit/GLKit.h>
#import "DelayLine.h"

//#define VECTOR_SIZE 2048


using namespace std;

class Soundshape
{
public:
    Soundshape();
    ~Soundshape();    
    void record(vector<float> audio_in);
    void record(float audio_in[],int in_size);
    void play(vector<float> &audio_out);
    void play(float audio_out[],int &out_size);
    void play(DelayLine &audio_out);
    void addPosition(CGPoint);
    void addPosition(float,float);
    void draw(GLKBaseEffect *);
    void move(CGPoint distance);
    void rotate(float rotation);
    float minDistanceFromPoint(CGPoint point);
    float splitPercent(CGPoint point);
    Soundshape split(float per);
    bool intersectsLine(float y);
    int posSize()
    {
        return positionSize;
    }
    int audSize()
    {
        return audioSize;
    }
    static void drawPlayhead(float x);
    static int closestShape(CGPoint point,Soundshape shapes[],int n);
    static int shapePicker(CGPoint point,Soundshape shapes[],int n);    
    static void drawLine(CGPoint a,CGPoint b);
    
private:
//    vector<float> audio;
    float *audio;
    CGPoint *pos;
    int positionSize;
    int audioSize;
};