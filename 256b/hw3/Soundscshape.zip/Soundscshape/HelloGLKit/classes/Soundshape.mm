//
//  Soundshape.h
//
//  Created by Mayank Sanganeria on 02/06/2012.
//  Copyright 2011 Stanford University. All rights reserved.
//

#include "Soundshape.h"
#include <math.h>

Soundshape::Soundshape()
{
    audio = new float[240000];
    audioSize=0;
    positionSize=0;
    pos = new CGPoint[1000];
}

Soundshape::~Soundshape()
{
//    delete audio;
//    delete pos;

}





void Soundshape::record(float audio_in[],int in_size)
{  
    for (int i=0;i<in_size;i++) {
        audio[audioSize]=audio_in[i];
        audioSize++;
    }
    
}   

void Soundshape::record(vector<float> audio_in)
{  
    for (int i=0;i<audio_in.size();i++) {
        audio[audioSize]=audio_in[i];
        audioSize++;
    }

}   

void Soundshape::play(float audio_out[],int &out_size)
{
    out_size=0;
    for (int i=0;i<audioSize;i++) {
        audio_out[out_size++]=audio[i];
    }
    
}


void Soundshape::play(DelayLine &audio_out)
{
    for (int i=0;i<audioSize;i++) {
        audio_out.write(audio[i]);
    }
    
}

void Soundshape::play(vector<float> &audio_out)
{
    audio_out.resize(audioSize);
    for (int i=0;i<audioSize;i++) {
        audio_out[i]=audio[i];
    }
    
}

//void Soundshape::addPosition(float x,float y)
//{
//    CGPoint point;
//    point.x=x;
//    point.y=y;
//    position.push_back(point);
//}

void Soundshape::move(CGPoint distance){
    for (int i=0;i<positionSize;i++)
    {
        pos[i].x+=distance.x;
        pos[i].y+=distance.y;        
    }
    
}

Soundshape Soundshape::split(float percent)
{
    Soundshape newShape;
    int splitPosition = positionSize*percent/100;
    int splitAudio = audioSize*percent/100;
    newShape.positionSize = positionSize-splitPosition;
    newShape.audioSize = audioSize-splitAudio;
    for (int i=0;i<newShape.positionSize;i++)
    {
        newShape.pos[i]=pos[i+splitPosition];
    }
    for (int i=0;i<newShape.audioSize;i++)
    {
        newShape.audio[i]=audio[i+splitAudio];
    }
    positionSize = splitPosition;
    audioSize = splitAudio;
    return newShape;
}


void Soundshape::rotate(float rotation){

    for (int i=0;i<positionSize;i++)
    {
        CGPoint newpos;
        newpos.x = pos[positionSize/2].x + (pos[i].x-pos[positionSize/2].x)*cosf(rotation)-(pos[i].y-pos[positionSize/2].y)*sinf(rotation);
        newpos.y = pos[positionSize/2].y + (pos[i].x-pos[positionSize/2].x)*sinf(rotation)+(pos[i].y-pos[positionSize/2].y)*cosf(rotation);        
        pos[i]=newpos;
    }
    
}


void Soundshape::addPosition(CGPoint point)
{
    //check if array is exceeded
    pos[positionSize++]=point;
}



float Soundshape::splitPercent(CGPoint point)
{
    int indexOfClosestPoint;
    float minDistSq = 100000;
    for (int i=0;i<positionSize;i++)
    {
        CGPoint dist;
        dist.x=(pos[i].x-point.x);
        dist.y=pos[i].y-point.y;
        float minD = dist.x*dist.x+dist.y*dist.y;
        if (minD<minDistSq) {
            minDistSq = minD;
            indexOfClosestPoint=i;
        }
    }
    
    return (float)indexOfClosestPoint*100/positionSize;
}




float Soundshape::minDistanceFromPoint(CGPoint point)
{
//    CGPoint minDist;
    float minDistSq = 100000;
    for (int i=0;i<positionSize;i++)
    {
        CGPoint dist;
        dist.x=(pos[i].x-point.x);
        dist.y=pos[i].y-point.y;
        float minD = dist.x*dist.x+dist.y*dist.y;
        if (minD<minDistSq) {
            minDistSq = minD;
//            minDist = dist;
        }
    }
        return powf(minDistSq,0.5);
}


int Soundshape::closestShape(CGPoint point, Soundshape shapes[],int num){
    if (num==0) return -1;
    float minDist=10000;
    int shapeNum=-1;
    for (int i=0;i<num;i++) {
        float dist=shapes[i].minDistanceFromPoint(point);
        if (dist<minDist) {
            minDist = dist;
            shapeNum = i;
        }
            
    }
    return shapeNum;
}

int Soundshape::shapePicker(CGPoint point, Soundshape shapes[],int num){
    if (num==0) return -1;
    int closest = closestShape(point,shapes,num);
    if (shapes[closest].minDistanceFromPoint(point)<100)
        return closest;
    return -1;
}



void Soundshape::draw(GLKBaseEffect *effect)
{
    GLubyte Indices[positionSize];
    
    typedef struct {
        float Position[3];
        float Color[4];
    } Vertex;
    
    Vertex Vertices[positionSize];
    
    for (int i=0;i<positionSize;i++)
    {     
        float theta = (float)i/4;
        //scaled values for iPad
        Vertices[i].Position[0]=pos[i].x/760*6-3;
        Vertices[i].Position[1]=-pos[i].y/1000*8+4;
        Vertices[i].Position[2]=0;
        Vertices[i].Color[0]=sin(theta)*sin(theta);
        Vertices[i].Color[1]=0;
        Vertices[i].Color[2]=0;
        Vertices[i].Color[3]=0;        
        Indices[i]=i;
    }
    
    GLuint _vertexBuffer;
    GLuint _indexBuffer;

    glGenBuffers(1, &_vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, _vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(Vertices), Vertices, GL_STATIC_DRAW);
    
    glGenBuffers(1, &_indexBuffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexBuffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Indices), Indices, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(GLKVertexAttribPosition);        
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const GLvoid *) offsetof(Vertex, Position));
    glEnableVertexAttribArray(GLKVertexAttribColor);
    glVertexAttribPointer(GLKVertexAttribColor, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const GLvoid *) offsetof(Vertex, Color));
    glLineWidth(5);
    glDrawElements(GL_LINE_STRIP, sizeof(Indices)/sizeof(Indices[0]), GL_UNSIGNED_BYTE, 0);
}

void Soundshape::drawPlayhead(float y)
{
    GLubyte Indices1[]={0,1,2};
    typedef struct {
        float Position[3];
        float Color[4];
    } Vertex;
    
    
    Vertex Vertices1[]={
        {{4,-y/1000*8+4,0},{1,0,0,0.2}},
        {{0,-y/1000*8+4,0},{0,0,1,1}},
        {{-4,-y/1000*8+4,0},{1,0,0,0.2}},
    };
    
    GLuint _vertexBuffer;
    GLuint _indexBuffer;
    
    glGenBuffers(1, &_vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, _vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(Vertices1), Vertices1, GL_STATIC_DRAW);
    
    glGenBuffers(1, &_indexBuffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexBuffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Indices1), Indices1, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(GLKVertexAttribPosition);        
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const GLvoid *) offsetof(Vertex, Position));
    glEnableVertexAttribArray(GLKVertexAttribColor);
    glVertexAttribPointer(GLKVertexAttribColor, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const GLvoid *) offsetof(Vertex, Color));
    glLineWidth(2);
    glDrawElements(GL_LINE_STRIP, sizeof(Indices1)/sizeof(Indices1[0]), GL_UNSIGNED_BYTE, 0);
   
}


bool Soundshape::intersectsLine(float y){
    for (int i=0;i<positionSize;i++)
    {
        if (pos[i].y==y)
            return 1;
    }
    
    return 0;
}


void Soundshape::drawLine(CGPoint a, CGPoint b)
{
    GLubyte Indices1[]={0,1};
    typedef struct {
        float Position[3];
        float Color[4];
    } Vertex;
    
    
    Vertex Vertices1[]={
        {{a.x/760*6-3,-a.y/1000*8+4,0},{0,1,1,1}},
        {{b.x/760*6-3,-b.y/1000*8+4,0},{0,1,1,0.2}},
//        {{0,0,0},{1,1,1,1}},
//        {{1,0,0},{1,1,1,1}},

    };
    
    GLuint _vertexBuffer;
    GLuint _indexBuffer;
    
    glGenBuffers(1, &_vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, _vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(Vertices1), Vertices1, GL_STATIC_DRAW);
    
    glGenBuffers(1, &_indexBuffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexBuffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Indices1), Indices1, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(GLKVertexAttribPosition);        
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const GLvoid *) offsetof(Vertex, Position));
    glEnableVertexAttribArray(GLKVertexAttribColor);
    glVertexAttribPointer(GLKVertexAttribColor, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const GLvoid *) offsetof(Vertex, Color));
    glLineWidth(2);
    glDrawElements(GL_LINE_STRIP, sizeof(Indices1)/sizeof(Indices1[0]), GL_UNSIGNED_BYTE, 0);
    

    
}

