//
//  HelloGLKitViewController.m
//  HelloGLKit
//
//  Created by Mayank Sanganeria on 2/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//



#import "HelloGLKitViewController.h"
#import <GLKit/GLKit.h>
#import "mo_audio.h"
#import <queue>
#import "Soundshape.h"
#import "DelayLine.h"

#define SRATE 24000
#define FRAMESIZE 512
#define NUMCHANNELS 2

#define PLAYHEAD_SPEED 10

// buffer
SAMPLE g_vertices[FRAMESIZE*4];
// last frame size
UInt32 g_lastNumFrames = 0;

//test recording
#define MAX_SHAPES 10
Soundshape g_shape[MAX_SHAPES];
int g_shape_size=0;

//DelayLines for global buffer sharing
DelayLine g_audio_out[MAX_SHAPES];

float g_audio_in[1024];
int g_in_size=0;

bool g_record=false;
bool g_recorded=false;
bool g_is_drawing=false;
bool g_is_playing=false;
bool g_drawline=false;

//location of 2 touches
CGPoint g_touch_a,g_touch_b;

// the audio callback

void audioCallback( Float32 * buffer, UInt32 frameSize, void * userData )
{
    g_lastNumFrames = frameSize;
    g_in_size=0;
    
    for( int i = 0; i < frameSize; i++ )
    {
        if (g_record){
            g_audio_in[g_in_size++]=buffer[2*i];
        }
        buffer[2*i] = buffer[2*i+1] = 0;        
        for (int j=0;j<g_shape_size;j++) {
            if (g_audio_out[j].size())
            {
                buffer[2*i] += g_audio_out[j].read();
                buffer[2*i+1] += g_audio_out[j].read();
                g_audio_out[j].advanceReadHead();
            }
        }
    }
    if (g_record)
        g_shape[g_shape_size].record(g_audio_in,g_in_size);
    
}


@interface HelloGLKitViewController () {
    float _curRed;
    BOOL _increasing;
    GLuint _vertexBuffer;
    GLuint _indexBuffer;
    float _rotation;
    
}
@property (strong, nonatomic) EAGLContext *context;
@property (strong, nonatomic) GLKBaseEffect *effect;

@end

@implementation HelloGLKitViewController 

@synthesize context = _context;
@synthesize effect = _effect;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


typedef struct {
    float Position[3];
    float Color[4];
} Vertex;

Vertex Vertices[] = {
    {{1, -1, 0}, {1, 1, 1, 1}},
    {{1, 1, 0}, {1, 1, 1, 1}},
    {{-1, 1, 0}, {0, 0, 1, 1}},
    {{-1, -1, 0}, {0, 0, 0, 1}}
};

const GLubyte Indices[] = {
    0, 1, 2,
    2, 3, 0
};


- (void)setupGL {
    
    [EAGLContext setCurrentContext:self.context];
    
    self.effect = [[GLKBaseEffect alloc] init];
    
    
}

- (void)tearDownGL {
    
    [EAGLContext setCurrentContext:self.context];
    
    glDeleteBuffers(1, &_vertexBuffer);
    glDeleteBuffers(1, &_indexBuffer);
    self.effect = nil;
    
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    
    if (!self.context) {
        NSLog(@"Failed to create ES context");
    }
    
    GLKView *view = (GLKView *)self.view;
    view.context = self.context;
    [self setupGL];
    // log
    NSLog( @"starting real-time audio..." );
    // init the audio layer
    bool result = MoAudio::init( SRATE, 64, 2 );
    if( !result )
    {
        // something went wrong
        NSLog( @"cannot initialize real-time audio!" );
        // bail out
        return;
    }
    // start the audio layer, registering a callback method
    result = MoAudio::start( audioCallback, NULL );
    if( !result )
    {
        // something went wrong
        NSLog( @"cannot start real-time audio!" );
        // bail out
        return;
    }
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    pan.maximumNumberOfTouches = 1;
    [self.view addGestureRecognizer:pan];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    tap.numberOfTapsRequired=2;
    [self.view addGestureRecognizer:tap];
    
    UILongPressGestureRecognizer *press = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    press.numberOfTouchesRequired = 2;
    press.allowableMovement = 100;
    [self.view addGestureRecognizer:press];
    
    UIRotationGestureRecognizer *rot = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotate:)];
    [self.view addGestureRecognizer:rot];    
    
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self tearDownGL];
    if ([EAGLContext currentContext] == self.context) {
        [EAGLContext setCurrentContext:nil];
    }
    self.context = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - GLKViewDelegate

float g_time_for_pulse;

- (void)glkView:(GLKView *)view drawInRect:(CGRect)rect {
    glClearColor(0.1*sin(g_time_for_pulse)*sin(g_time_for_pulse), 0.1*sin(g_time_for_pulse)*sin(g_time_for_pulse), 0.1*sin(g_time_for_pulse)*sin(g_time_for_pulse), 1.0);
    
    glClear(GL_COLOR_BUFFER_BIT);
    [self.effect prepareToDraw];

    if (g_is_drawing)
    g_shape[0].draw(self.effect);
    for (int i=0;i<g_shape_size;i++)
        g_shape[i+g_is_drawing].draw(self.effect);
    static float t=0;
    static bool g_shape_played[]={false,false,false,false,false,false,false,false,false,false};
    if (g_is_playing)
    {
        Soundshape::drawPlayhead(t);
        t+=PLAYHEAD_SPEED;
        if (t>1000) {
            g_is_playing=false;
            t=0;
            for (int i=0;i<MAX_SHAPES;i++)
                g_shape_played[i] = 0;
        }
        for (int i=0;i<g_shape_size;i++)
            if (g_shape[i].intersectsLine(t) && g_shape_played[i]==0) {
                g_shape[i].play(g_audio_out[i]);
                g_shape_played[i]=1;
            }
    }
    
    if (g_drawline)
    {
        Soundshape::drawLine(g_touch_a,g_touch_b);
    }
    
    
}

#pragma mark - GLKViewControllerDelegate

- (void)update {
    g_time_for_pulse+=0.02;
    if ( g_time_for_pulse>100) g_time_for_pulse = 0;
    float aspect = fabsf(self.view.bounds.size.width / self.view.bounds.size.height);
    GLKMatrix4 projectionMatrix = GLKMatrix4MakePerspective(GLKMathDegreesToRadians(65.0f), aspect, 4.0f, 10.0f);    
    self.effect.transform.projectionMatrix = projectionMatrix;
    
    GLKMatrix4 modelViewMatrix = GLKMatrix4MakeTranslation(0.0f, 0.0f, -6.0f);   
//    _rotation += 90 * self.timeSinceLastUpdate;
    modelViewMatrix = GLKMatrix4Rotate(modelViewMatrix, GLKMathDegreesToRadians(_rotation), 0, 0, 1);
    self.effect.transform.modelviewMatrix = modelViewMatrix;
    
    
}

-(void)handlePan:(UIPanGestureRecognizer *)sender
{

    
    //check if user is trying to select a current object
    CGPoint point = [sender locationInView:self.view];
    static int num;
    if (sender.state == UIGestureRecognizerStateBegan)
        num=Soundshape::shapePicker(point, g_shape, g_shape_size);
    else {
    //if not, draw a new object
    if (num==-1)
    {
        if (g_shape_size<MAX_SHAPES){
            CGPoint point = [sender locationInView:self.view];
            g_shape[g_shape_size].addPosition(point);
            g_is_drawing=true;
            g_record=true;
            if (sender.state==UIGestureRecognizerStateEnded) {
                g_shape_size++;
                g_is_drawing=false;
                g_record=false;
            }
        }
    }
    //otherwise move object
    else {
        CGPoint trans = [sender translationInView:self.view];
        g_shape[num].move(trans);
        CGPoint zero;
        zero.x=0;zero.y=0;
        [sender setTranslation:zero inView:self.view];
    }
    }
}    
-(void)handleTap:(UITapGestureRecognizer *)sender
{
    CGPoint point = [sender locationInView:self.view];
    int closestShape = Soundshape::closestShape(point, g_shape, g_shape_size);
    if (closestShape != -1)
    {
        g_shape[closestShape].play(g_audio_out[closestShape]);
    }

}

-(void)longPress:(UITapGestureRecognizer *)sender
{
    g_drawline=true;
    g_touch_a = [sender locationOfTouch:0 inView:self.view];
    g_touch_b = [sender locationOfTouch:1 inView:self.view];
    if (sender.state == UIGestureRecognizerStateEnded)
    {
        g_drawline = false;
        CGPoint point = [sender locationInView:self.view];
        int closestShape = Soundshape::shapePicker(point, g_shape, g_shape_size);
        if (closestShape != -1)
        {
//            NSLog(@"%i",closestShape);
            float percent = g_shape[closestShape].splitPercent(point);
//            NSLog(@"%f",percent);
            g_shape[g_shape_size++]=g_shape[closestShape].split(percent);
        }
    }   
}

-(void)rotate:(UIRotationGestureRecognizer *)sender{

    CGPoint point = [sender locationInView:self.view];
    int closestShape = Soundshape::closestShape(point, g_shape, g_shape_size);
    if (closestShape != -1)
    {
        g_shape[closestShape].rotate((float)sender.rotation);
        sender.rotation = 0;
    }

}

    
- (IBAction)Play:(id)sender {
//    for (int i=0;i<g_shape_size;i++) {
//        g_shape[i].play(g_audio_out[i]);
//    }
    g_is_playing=true;
}
@end
