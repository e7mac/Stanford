
y = wavread('JCRevImpulse.wav');

figure();
title('echogram');
subplot(211);
stem(y(1:6000,1));
subplot(212);
stem(y(1:6000,2));



figure();
title('dB magnitude spectra');
subplot(211);
plot(20*log10(abs(fft(y(1:44100,1)))));
subplot(212);
plot(20*log10(abs(fft(y(1:44100,1)))));


figure();
title('spectrogram');
subplot(211);
spectrogram(y(1:44100,1),2048);
subplot(212);
spectrogram(y(1:44100,2),2048);
