/* parallelWalls.cpp - simulation of parallel walls system
   Compatible with STK version 4.4.4.

   Usage:

     parallelWalls

   Outputs the impulse response
*/
   
#include "FileWvIn.h"
#include "FileWvOut.h"
#include "JCRev.h"
#include <stdlib.h>

using namespace stk;

int main(int argc,char *argv[])
{
    const int nChan = 2;
    Stk::setSampleRate(44100);
    FileWvOut output("JCRevImpulse.wav", nChan);
    //setup state
    StkFrames frame(1,2);
    frame(0,0) = 1;
    frame(0,1) = 1;
    JCRev rev;
    for (int i=0;i<44100*3;i++)   { // output 6000 samples
        output.tick(rev.tick(frame));
        frame(0,0) = 0;
        frame(0,1) = 0;
    }
}
