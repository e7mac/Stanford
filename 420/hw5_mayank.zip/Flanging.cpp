#include "Flanging.h"
#include <math.h>
 
namespace stk {

Flanging :: Flanging(StkFloat depthIn)
{
  sweep = 0.9; // how far delay is moving (0.1 -> 10\% deviation)
  speed = 4; // how fast delay is moving
  // The average delay
  avgDelay = 100;
  delayLine = new DelayL(avgDelay,(long)(avgDelay*(1+sweep)));
    depth = depthIn;
  count = 0.0;
    feedback = 0.5;
    phaseInvert = 1;
}
 
Flanging :: ~Flanging()
{
  delete delayLine;
}
 
void Flanging :: clear(void)
{
  delayLine->clear();
  depth = 0.0;
  sweep = 0.0;
  speed = 0.0;
  avgDelay = 0.0;
  count = 0.0;
    feedback = 0.0;
}
 
void Flanging :: setDepth(StkFloat depthIn)
{
  depth = depthIn;
}
 
StkFloat Flanging :: tick(StkFloat sample)
{
    static int t;
    t++;
    int phaseSign = (phaseInvert) ? -1 : 1;
    delayLine->setDelay(avgDelay * (1.0  - sweep*sinf(2 * M_PI / 44100 * speed * t )) );
    StkFloat output = 0.5*sample + 0.5*phaseSign*depth*delayLine->tick(sample + feedback*output);
    return output;
}

} // stk namespace
