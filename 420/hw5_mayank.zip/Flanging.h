#if !defined(__FLANGING_H)
#define __FLANGING_H
 
#include "../../include/Stk.h"
#include "../../include/DelayL.h"


namespace stk {

class Flanging
{
public:
 
  //Default constructor
  Flanging();
 
  // Overloaded constructor, setting flanging depth
  Flanging(StkFloat depthIn);
    
  // Class destructor.
  ~Flanging();
 
  // Clear the internal states
  void clear(void);
 
  // Set flanging depth
  void setDepth(StkFloat depthIn);
  
  // Input one sample and return one output
  StkFloat tick(StkFloat sample);
                                                                               
private:
  StkFloat sweep; // how far delay is moving (A)
  StkFloat speed; // how fast delay is moving (f)
  StkFloat avgDelay; // average base delay (M0)
  DelayL *delayLine; // delay line in feed-forward comb filter
  StkFloat depth; // depth (g)
  StkFloat count; // count sweeping delay instance
     StkFloat feedback;
    bool phaseInvert;
};

} // stk namespace

#endif
