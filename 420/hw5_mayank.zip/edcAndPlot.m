% edcAndPlot.m  
% calculate and plot the Energy Decay Curve of a signal

fileName = 'BigHall.wav'; % name of soundfile to be analyzed
minPlotDB = -60; % minimum value in DB to be plotted

[signal,fs,bits] = wavread(fileName);
nSamp = length(signal);

% calculate the EDC
signalEDC_DB = zeros(1,nSamp);
     %%% WRITE CODE HERE %%%
     for i = nSamp - 1 : -1 : 1
        signalEDC_DB(i) = abs(signal(i))^2 + signalEDC_DB(i+1);
     end
     signalEDC_DB = 10*log10(signalEDC_DB);

     % The variable "signalEDC_DB" is the EDC in units of decibels.
     % Implementation hint: It is faster to calculate the EDC going
     % backward in time rather than forward.

% normalize the EDC to 0 dB
maxSignalEDC_DB = max(signalEDC_DB);
signalEDC_DB_N = signalEDC_DB - maxSignalEDC_DB;

% plot the energy decay curve
timeAxis = (0:length(signal)-1)/fs; % time axis in seconds
figure(gcf);clf;
plot(timeAxis,signalEDC_DB_N);grid;
v = axis; axis([v(1) v(2) minPlotDB v(4)]); % to reduce vertical axis
title('Normalized Energy Decay Curve (EDC)');
xlabel('time (s)');ylabel('magnitude (dB)');
zoom on;
figure();
plot(timeAxis, signal);
title('Echogram');
xlabel('time (s)');ylabel('magnitude');

