#include <cstdlib>
#include "Flanging.h"
#include "Noise.h"
#include "FileWvIn.h"
#include "FileWvOut.h"
using namespace stk;

int main()
{

  //***********************************************************
  //***********************************************************
  //SETUP YOUR INPUTS HERE
   FileWvIn *input = new FileWvIn( "alb.wav");
   int nsamps = input->getSize();
   StkFloat fs = input->getFileRate();
   Stk::setSampleRate(fs); // set sampling rate
   StkFloat nchans = input->channelsOut();
   if (nchans != 1) { 
     StkError("testFlanging.cpp:: Can only handle one audio channel");
     //handleError( StkError::WARNING );
   }

  //***********************************************************
  //***********************************************************
 
   // Output file
   FileWvOut *output;
   output = new FileWvOut( "testFlanging.wav", 1, FileWrite::FILE_WAV, Stk::STK_SINT16 );
 
   // instantiate Flanging object
   StkFloat depth = 1.0; // flanging depth in [0,1] range
   Flanging *flang;
   flang = new Flanging(depth);
    
    // Run the oscillator for nsamps samples, writing to the output file
   int i;
   for ( i=0; i<nsamps; i++ ) {
     output->tick(flang->tick(input->tick()));
     //output->tick(0.2*input->tick());
   }
   // Output the rest of the delay line (approximate number)
   for ( i=0; i<22050; i++ ) {
     output->tick(flang->tick(0));
   }
    
   // Clean up
   delete input;
   delete output;
 
   return 0;
}
