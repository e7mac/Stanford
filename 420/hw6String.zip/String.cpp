#include "String.h"

using namespace std;

String::String(float withFrequency,float withPluckedPosition,float withObservingPosition)
{
    // user stuffs
    frequency = withFrequency;
    pluckedPosition = withPluckedPosition;
    observingPosition = withObservingPosition;
    
    pluckIndex = floor(pluckedPosition * halfDelayLength);
    observeIndex = floor(observingPosition * halfDelayLength);

    // loop filter
    float coefs_array[] = {0.25,0.50.25};
    vector<float> coefs(coefs_array, coefs_array + sizeof(coefs_array) / sizeof(float));
    feedbackFilter = new Fir(coefs);
    
    // delay line
    halfDelayLength = Stk::sampleRate()/frequency;
    delayLength = 2.0 * halfDelayLength;
    delay = new DelayA(delayLength,2.0 * delayLength);
    
}

float String::tick()
{
    return tick(0.0);
}


float String::tick(float pluckValue)
{
    delay->tapIn(pluckValue, pluckIndex);
    delay->tapIn(pluckValue, pluckIndex + halfDelayLength);
    delay->tick(0.5 * (delay->nextOut() + feedbackFilter->tick(delay->lastOut()) ) );
    float outputSample = 0.5 * (delay->tapOut(observeIndex) + delay->tapOut(observeIndex + halfDelayLength));
    return outputSample;
}


String::~String()
{
    delete delay;
    delete feedbackFilter;
}
