#include <vector>
#include "Stk.h"
#include "DelayA.h"
#include "Fir.h"

using namespace stk;

class String
{
public:
    String(float fundamentalFrequency,float pluckedPos,float observingPos);
    ~String();
    
    float tick();
    float tick(float pluckValue);
    
private:
    float frequency;
    float pluckedPos;
    float observingPos;
    int pluckIndex;
    int observeIndex;

    float halfDelayLength;
    float delayLength;
    DelayA* delay;
    Fir* feedbackFilter;
    
};

#endif
