#include "ElecGuitar.h"
#include <Noise.h>
#include <FileWvOut.h>
#include <iostream>
#include <OnePole.h>


ElecGuitar::ElecGuitar()
{
    // init vars
    noiseBurstLength = 50;
    delay = new Delay(noiseBurstLength,noiseBurstLength);
    isNoteOn = 0;
    
    feedback = 0.0;
    feedbackState = 0.0;
    
    float guitarStringLength = 22.5;
    // default pickup position
    pickupPosition = 0.5;//1.0 / guitarStringLength;

    // default observing position
    observingPosition = 0.5;//3.0 / guitarStringLength;
    
    
    
    
    // standard guitar tuning

    stringFrequencies.push_back(329.63);
    stringFrequencies.push_back(246.94);
    stringFrequencies.push_back(196.00);
    stringFrequencies.push_back(146.83);
    stringFrequencies.push_back(110.00);
    stringFrequencies.push_back(82.41);

  // create each string
    for (size_t i = 0; i < this->stringFrequencies.size(); ++i)
    {
        strings.push_back(new Stringy(stringFrequencies[i],pickupPosition, observingPosition));
    }
}

void ElecGuitar::initNoiseDelayLine()
{
    delete delay;
    delay = new Delay(noiseBurstLength,noiseBurstLength);

}

void ElecGuitar::setNoiseBurstLength(int length)
{
    noiseBurstLength = length;
    initNoiseDelayLine();
}

void ElecGuitar::pluck()
{
    // filtered noise
    Noise noise;
    OnePole lp(0.5);
    for (int i=0;i<noiseBurstLength;i++)
        delay->tick(lp.tick(noise.tick()));
}


float ElecGuitar::tick(float inSamp)
{
    float outputSamp = 0;
    float inputSamp = inSamp/strings.size() + isNoteOn * delay->tick(0.0);
    for (unsigned int i=0;i<strings.size();i++)
    {
        outputSamp += strings[i]->tick(inputSamp + feedback * feedbackState);
    }
    feedbackState = outputSamp/strings.size();
    return feedbackState;    
}


float ElecGuitar::tick()
{
    return tick(0);
}

void ElecGuitar::noteOn()
{
    isNoteOn = 1;
}

void ElecGuitar::noteOff()
{
    isNoteOn = 0;
}


void ElecGuitar::setPluckPosition(float position)
{
    for (unsigned int i=0;i<strings.size();i++)
        strings[i]->setPluckingPosition(position);
}
void ElecGuitar::setObserverPosition(float position)
{
    for (unsigned int i=0;i<strings.size();i++)
        strings[i]->setObservingPosition(position);
}

void ElecGuitar::setFeedback(float fbAmt)
{
    feedback = fbAmt;
}