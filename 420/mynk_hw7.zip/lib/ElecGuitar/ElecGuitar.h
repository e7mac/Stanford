#ifndef _ELECGUITAR_H_
#define _ELECGUITAR_H_

#include <Stk.h>
#include "Stringy/Stringy.h"
#include <Delay.h>
using namespace stk;
using namespace std;

class ElecGuitar
{
public:
  ElecGuitar();
//  ~ElecGuitar();
    void pluck();
    float tick();
    float tick(float inSamp);
    
    void noteOn();
    void noteOff();
    void initNoiseDelayLine();
    void setPluckPosition(float position);
    void setObserverPosition(float position);
    void setNoiseBurstLength(int length);
    void setFeedback(float fbAmt);
private:
  /* Fundamental frequencies of each string */
  vector<stk::StkFloat> stringFrequencies;

  /* Pickup position [0, 1] */
  StkFloat pickupPosition;
    StkFloat observingPosition;
  /* Actual string instances */
  vector<Stringy*> strings;
    Delay *delay;
    int noiseBurstLength;
    bool isNoteOn;
    float feedback;
    float feedbackState;
};

#endif
