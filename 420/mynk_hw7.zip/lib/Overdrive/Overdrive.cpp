#include "Overdrive.h"

Overdrive::Overdrive(float pre, float post)
{
    preGain = pre;
    postGain = post;
}

float Overdrive::tick(float insamp)
{
    float outsamp;
    outsamp = preGain * insamp;
    //nonlinear dist
    outsamp = outsamp / (1 + outsamp);
    outsamp *= postGain;
    return outsamp;
}