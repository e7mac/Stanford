#ifndef _OVERDRIVE_H
#define _OVERDRIVE_H

#include <Stk.h>

using namespace stk;

class Overdrive
{
public:

    Overdrive(float pre, float post);
    float tick(float insamp);
private:
    float preGain;
    float postGain;
};

#endif
