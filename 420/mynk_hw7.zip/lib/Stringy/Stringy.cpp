#include "Stringy.h"

Stringy::Stringy(
  StkFloat fundamentalFrequency,
  StkFloat pluckedPosition,
  StkFloat observingPosition
) {
  // user parameters
  _fundamentalFrequency = fundamentalFrequency;
  _pluckedPosition = pluckedPosition;
  _observingPosition = observingPosition;

  // delay length of optimized delay line
    _delayLength = Stk::sampleRate() / _fundamentalFrequency;
  _delay = new DelayA(
    _delayLength,
    // max delay length is 2.0 times for safe measure
    2.0 * _delayLength
  );

  // index in delay line(s) to use for plucking and observing positions
  _tapInIndex = floor(_pluckedPosition * _delayLength);
  _tapOutIndex = floor(_observingPosition * _delayLength);

  // initialize frequency dependent feedback loop filter
  std::vector<StkFloat> coefs(3);
  coefs.push_back(0.25);
  coefs.push_back(0.5);
  coefs.push_back(0.25);
  _feedbackGain = new Fir(coefs);
}

Stringy::~Stringy() {

  delete _delay;
  delete _feedbackGain;

}

void Stringy::pluck() {
  // just impulse for now
  _delay->tapIn(1.0, _tapInIndex);
  _delay->tapIn(1.0, _delayLength - _tapInIndex);
}

StkFloat Stringy::tick(StkFloat inSamp) {
  _delay->tapIn(_delay->tapOut(_tapInIndex) + inSamp, _tapInIndex);
  _delay->tapIn(_delay->tapOut(_tapInIndex) + inSamp, _delayLength - _tapInIndex);

  return tick();
}

StkFloat Stringy::tick() {
  _delay->tick(
    // 0.5 to eliminate clipping
    0.5 * (
      // y+(n)
      _delay->nextOut()
      // g * y(n - N)
      + _feedbackGain->tick(_delay->lastOut())
    )
  );

  // return sample from observation point
  return 0.5 * (
    // observing at phantom left-going
    _delay->tapOut(_tapOutIndex)
    // observing at phantom right-going
    + _delay->tapOut(_delayLength - _tapOutIndex)
  );
}

void Stringy::setPluckingPosition(float inPos)
{
    _pluckedPosition = inPos;
    
}
void Stringy::setObservingPosition(float inPos)
{
    _observingPosition = inPos;
}
