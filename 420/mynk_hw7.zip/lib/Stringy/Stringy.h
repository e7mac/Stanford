#ifndef _STRINGY_H_
#define _STRINGY_H_

#include <vector>

#include <Stk.h>
#include <DelayA.h>
#include <Fir.h>

using namespace stk;

class Stringy
{
public:
    Stringy(StkFloat fundamentalFrequency,StkFloat pluckedPosition,StkFloat observingPosition);
    ~Stringy();
    StkFloat tick();
    StkFloat tick(StkFloat inSamp);
    void pluck();
    void setPluckingPosition(float inPos);
    void setObservingPosition(float inPos);
    
private:
    StkFloat _fundamentalFrequency;
    StkFloat _pluckedPosition;
    StkFloat _observingPosition;
    StkFloat _halfDelayLength;
    StkFloat _delayLength;
    DelayA* _delay;
    Fir* _feedbackGain;
    unsigned int _tapInIndex;
    unsigned int _tapOutIndex;
};

#endif
