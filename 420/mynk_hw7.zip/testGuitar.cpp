#include <iostream>
#include "ElecGuitar/ElecGuitar.h"
#include "Stringy/Stringy.h"
#include "Overdrive/Overdrive.h"
#include <FileWvOut.h>
#include <Delay.h>

using namespace stk;

int main(int argc, char const *argv[])
{
    
    //amp feedback controls
    float fbGain = 0.3;
    int fbDelay = 4410;
    float fbSample = 0.0;
    Delay feedbackDelay(fbDelay,fbDelay);
    FileWvOut output("out.wav");
    ElecGuitar elec;
    Overdrive over(2,0.5);
    elec.noteOn();
    elec.pluck();
    
    for (int i=0;i<44100*2;i++)
    {
        float outputSample = over.tick(elec.tick(fbSample));
        fbSample = fbGain * feedbackDelay.tick(outputSample);
        output.tick(outputSample);
    }
    return 0;
}
