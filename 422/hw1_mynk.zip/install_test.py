﻿# A simple test file to verify that numpy and matplotlib are installed and working

# import necessary libraries
import numpy as np                   # to access numpy arrays (and math functions)
import pylab                         # to access matplotlib plotting routines 

#prepare some data to plot
N= 2048                              # the number of data points
pi = np.pi                           #  you need to import math stuff from "numpy” (or “math”)
t = np.arange(N)                     # t is an array that ranges from 0 to N-1
x = np.cos(2 * pi * 440. * t / 44100) * np.sin(pi * t / N)  # a simple function of t to plot

# plot data
pylab.plot(t,x,'r-')                 # make a plot of x vs t ( ‘r-‘ means red solid line)
pylab.xlabel("Sample Number")        # label the x-axis
pylab.ylabel("Signal")               # label the y-axis
pylab.xlim(0,N)                      # set the x-axis range (use ylim for y-axis)
pylab.grid(True)                     # show gridlines
pylab.title("A simple graph")        # add title
pylab.show()                         # show the graph
