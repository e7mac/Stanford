fs = 16000;
t=0:1/fs:0.5-1/fs;
y=sin(3000*pi*t).*sin(2*pi*t);
plot(y);