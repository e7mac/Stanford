clear all;

% compute at 16 kHZ

fs = 16000;
time=0:1/fs:0.5-1/fs;
x=sin(3000*pi*time).*sin(2*pi*time);


% use x to do sinc interpolation
upsample_factor = 5;
x_est = zeros(1,length(time)*upsample_factor);
for t=1:length(time)*upsample_factor
    for n=1:length(x)
        commonTerm = pi*fs*((t-1)/(fs*upsample_factor)-(n-1)/fs);
        if (commonTerm == 0)
            factor = 1;
        else
            factor = sin(commonTerm)/commonTerm;
        end
        x_est(t) = x_est(t) + x(n)*factor;
    end
end


% create higher sampling rate version
fs_higher = upsample_factor * fs;
t_higher=0:1/fs_higher:0.5-1/fs_higher;
x_higher=sin(3000*pi*(t_higher)).*sin(2*pi*(t_higher));
plot(x_higher - x_est);