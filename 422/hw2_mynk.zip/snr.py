import numpy as np
import matplotlib.pyplot as plt
from quantize import *

# Plot the SNR
def main():
    # create sin wave
    freq = 3100.0
    fs = 16000.0
    t = np.linspace(0, 1.0, 1.0*fs)
    sig = np.sin(2*np.pi*freq*t)

    # set up an amplitude array
    amp = np.logspace((-50.0/20.0), 0, 200)
    plt.hold(True)

    # 8 bits uniform
    snrMT = np.zeros_like(amp)
    for i in range(0, len(amp)-1):

        newSig = amp[i]*sig

        mtVal = vDequantizeUniform( vQuantizeUniform( newSig, 8 ), 8 )
        mtErr = mtVal - newSig

        sigPwr = (amp[i])**2/2.0
        errPwr = (1.0/len(mtErr))*np.sum(mtErr**2)

        snrMT[i] = 10*np.log10(sigPwr/(errPwr + np.spacing(1)) + np.spacing(1))

    plotMT8, = plt.plot(10*np.log10(amp**2/2.0),snrMT)

    # 12 bits uniform
    snrMT12 = np.zeros_like(amp)
    for i in range(0, len(amp)-1):
        
        newSig = amp[i]*sig
        
        mt12Val = vDequantizeUniform( vQuantizeUniform( newSig, 12 ), 12 )
        mt12Err = mt12Val - newSig
        
        sigPwr = (amp[i])**2/2.0
        errPwr = (1.0/len(mt12Err))*np.sum(mt12Err**2)
        
        snrMT12[i] = 10*np.log10(sigPwr/(errPwr + np.spacing(1)) + np.spacing(1))
    
    plotMT12, = plt.plot(10*np.log10(amp**2/2.0), snrMT12, 'g')
            
    # 3s5m FP
    snrFP = np.zeros_like(amp)
    fp = np.ones_like(sig)
    for i in range(0, len(amp)-1):

        newSig = amp[i]*sig
        
        t = 0
        for s in newSig:
            scale = ScaleFactor(s)
            mantissa = MantissaFP(s, scale)
            fp[t] = DequantizeFP(scale, mantissa)
            t = t + 1
        fpVal = fp
        fpErr = fpVal - newSig

        sigPwr = (amp[i]**2)/2.0
        errPwr = (1.0/len(fpErr))*np.sum(fpErr**2)

        snrFP[i] = 10*np.log10(sigPwr/(errPwr + np.spacing(1)) + np.spacing(1))


    plotFP, = plt.plot( 10*np.log10(amp**2/2.0), snrFP, 'r')
    plt.hold(True)
    
    # display the plot
    plt.xlim(-50, 0)
    plt.ylim(0, 100)
    plt.title("SNR plots")
    plt.xlabel("Input Level (dB)")
    plt.ylabel("SNR (dB)")
    plt.legend([plotMT8, plotFP, plotMT12], ["8-bit MT", "3s5m FP", "12-bit MT"])
    plt.show( )    
if __name__ == "__main__":
    main()