import numpy as np
import window
import matplotlib.pyplot as plt
import normalization
import mdct
import psychoac


if __name__ == "__main__":
    pi = np.pi
    cos = np.cos
    fs = 48000
    Ns = [512, 1024, 2048]
    # comment out below for 1b    
    Ns = [1024]
    for N in Ns:
        n = np.linspace(0, N-1, N)
        a = [0.45, 0.15, 0.15, 0.10, 0.06, 0.05]
        x = a[0]*cos(2*pi*440.*n/fs) + a[1]*cos(2*pi*550.*n/fs) + a[2]*cos(2*pi*660.*n/fs) + a[3]*cos(2*pi*880.*n/fs) + a[4]*cos(2*pi*4400.*n/fs) + a[5]*cos(2*pi*8800.*n/fs)
        x_hanning = window.HanningWindow(x)
        w2_hanning = 0.375
        dftx = np.fft.fft(x_hanning)[0:N/2]
        binFreqs = (np.linspace(0, pi, len(dftx)) * fs) / (2 * pi)
        spl_dftx = normalization.SPL_dft(dftx,window.HanningWindow(np.ones(N)))
        plt.semilogx(binFreqs, spl_dftx, label="N="+str(N))
        plt.title("SNR plot")
        plt.xlabel("Freq(Hz)")
        plt.ylabel("SNR (dB)")
        plt.plot(binFreqs,psychoac.Thresh(binFreqs),'-',label="Threshold")
        barks = psychoac.Bark(binFreqs)
        
        masterMasker = np.zeros_like(binFreqs)
        
        # get peaks
        for i in range(N/2-3):
            if spl_dftx[i+1]>spl_dftx[i] and spl_dftx[i+1]>spl_dftx[i+2]:
                intensity_peak = psychoac.Intensity(spl_dftx[i+1])
                intensity_peak_less = psychoac.Intensity(spl_dftx[i])
                intensity_peak_more = psychoac.Intensity(spl_dftx[i+2])
                intensity_sum = intensity_peak + intensity_peak_less + intensity_peak_more
                spl_intensity = psychoac.SPL(intensity_sum)

                frequency = ( (intensity_peak * binFreqs[i+1]) + (intensity_peak_less * binFreqs[i]) + (intensity_peak_more * binFreqs[i+2]) ) / (intensity_peak + intensity_peak_less + intensity_peak_more)
                if N == 1024:
                    masker = psychoac.Masker(frequency, spl_intensity, True)
                    maskerIntensity = masker.vIntensityAtBark(barks)
                    masterMasker += maskerIntensity
                    maskerSPL = psychoac.SPL(maskerIntensity)
                    plt.semilogx(binFreqs, maskerSPL, label="masker")
                plt.plot(frequency,spl_intensity,'rx')

    masterMaskerSPL = psychoac.SPL(masterMasker)
    plt.semilogx(binFreqs, masterMaskerSPL, label="overall masker")
    plt.ylim(-10,100)
#    plt.xlim(100,11000)
    plt.legend()
    sfBands = psychoac.ScaleFactorBands( psychoac.AssignMDCTLinesFromFreqLimits(N/2, fs) )
    mdctBinFreqs = (np.arange(N/2) + 0.5) / (N/2) * (fs * 0.5)
    # drawing just upper for clarity
#    for band in sfBands.upperLine:
#        plt.vlines(mdctBinFreqs[band],-10,100)
    for band in sfBands.lowerLine:
        plt.vlines(mdctBinFreqs[band],-10,100)
    plt.show()
