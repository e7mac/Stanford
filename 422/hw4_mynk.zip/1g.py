import numpy as np
import window
import matplotlib.pyplot as plt
import normalization
import mdct
import psychoac


if __name__ == "__main__":
    pi = np.pi
    cos = np.cos
    fs = 48000
    plt.hold()
    N = 1024
    
    # generate signal
    n = np.linspace(0, N-1, N)
    a = [0.45, 0.15, 0.15, 0.10, 0.06, 0.05]
    x = a[0]*cos(2*pi*440.*n/fs) + a[1]*cos(2*pi*550.*n/fs) + a[2]*cos(2*pi*660.*n/fs) + a[3]*cos(2*pi*880.*n/fs) + a[4]*cos(2*pi*4400.*n/fs) + a[5]*cos(2*pi*8800.*n/fs)
    # window signal
    x_sine = window.SineWindow(x)
    w2_sine = 0.5
    mdctx = mdct.MDCT(x_sine,N/2,N/2)
    
    sfBands = psychoac.ScaleFactorBands( psychoac.AssignMDCTLinesFromFreqLimits(N/2, fs) )
    smrs = psychoac.CalcSMRs(x, mdctx, 0, fs, sfBands)
    for smr in smrs:
        print smr
