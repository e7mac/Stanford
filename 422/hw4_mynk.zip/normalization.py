import numpy as np

def SPL_dft(Y, w):
    Y = np.absolute(Y)
    Y = Y*Y
    wN = len(w)
    w2 = 1.0 * np.sum(w*w) / wN
    spls = []
    scale = 4.0 / ((pow(wN,2.0)) * w2)
    for y in Y:
        if y:
            spls.append(96.0 + 10.0 * np.log10(scale * y))
        else:
            spls.append(96.0)
    return np.array(spls)

def SPL_mdct(Y, w):
    Y = np.absolute(Y)
    wN = len(w)
    Y = Y * Y * wN * wN / 4
    w2 = 1.0  * np.sum(w*w)/wN
    spls = []
    scale = 8.0 / ((pow(wN,2.0)) * w2)
    for y in Y:
        if y:
            spls.append(96.0 + 10.0 * np.log10(scale * y))
        else:
            spls.append(96.0)
    return np.array(spls)