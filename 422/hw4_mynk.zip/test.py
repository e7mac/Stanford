from psychoac import *

s =  ScaleFactorBands(AssignMDCTLinesFromFreqLimits(512, 48000))
