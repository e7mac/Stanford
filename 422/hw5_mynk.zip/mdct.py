"""
- mdct.py -- Computes reasonably fast MDCT/IMDCT using numpy FFT/IFFT
"""

### ADD YOUR CODE AT THE SPECIFIED LOCATIONS ###

import numpy as np
import matplotlib.pyplot as plt
import window
import time

### Problem 1.a ###
def MDCTslow(data, a, b, isInverse=False):
    """
    Slow MDCT algorithm for window length a+b following pp. 130 of
    Bosi & Goldberg, "Introduction to Digital Audio..." book
    (and where 2/N factor is included in forward transform instead of inverse)
    a: left half-window length
    b: right half-window length
    """
    
    ### YOUR CODE STARTS HERE ###
    
    N = int(a + b)
    n0 = (b + 1.0) / 2.0
    
    if isInverse:
        transformedData = np.zeros(N,dtype=float)
        for n in range(N):
            for k in range(N/2):
                transformedData[n] += 2.0 * float(data[k])*np.cos(2.0*np.pi/N*(n+n0)*(k+0.5) )
    else:
        transformedData = np.zeros(N/2,dtype=float)
        for k in range(N/2):
            for n in range(N):
                transformedData[k] += 2.0/N * float(data[n])*np.cos(2.0*np.pi/N*(n+n0)*(k+0.5) )
    return transformedData
    ### YOUR CODE ENDS HERE ###

### Problem 1.c ###
def MDCT(data, a, b, isInverse=False):
    """
    Fast MDCT algorithm for window length a+b following pp. 141-143 of
    Bosi & Goldberg, "Introduction to Digital Audio..." book
    (and where 2/N factor is included in forward transform instead of inverse)
    a: left half-window length
    b: right half-window length
    """

    ### YOUR CODE STARTS HERE ###
    N = int(a+b)
    n0 = (b + 1.0) / 2.0
    data = np.array(data, dtype=np.complex)
    if not isInverse:
        theta = -2*np.pi/(2*N)
        preTwiddle = theta * np.linspace(0,N-1,N)
        preTwiddle = np.cos(preTwiddle) + 1j * np.sin(preTwiddle)
        data = np.multiply( data, preTwiddle )
        transformedData = np.fft.fft(data)
        alpha = -2*np.pi/N*n0
        postTwiddle = alpha * (0.5 + np.linspace(0,N/2-1,N/2))
        postTwiddle = np.cos(postTwiddle) + 1j * np.sin(postTwiddle)
        transformedData = np.real(2.0/N*transformedData[0:N/2]*postTwiddle)
        return transformedData

    else:
        theta = 2.0*np.pi / N * n0
        preTwiddle = theta * np.linspace(0,N-1,N)
        preTwiddle = np.cos(preTwiddle) + 1j * np.sin(preTwiddle)
        data = np.concatenate([ data, -1.0 * data[::-1] ])
        data *= preTwiddle
        transformedData = np.fft.ifft(data)
        alpha = np.pi/N
        postTwiddle = alpha * (n0 + np.linspace(0,N-1,N))
        postTwiddle = np.cos(postTwiddle) + 1j * np.sin(postTwiddle)
        transformedData = np.real(transformedData * postTwiddle )
        transformedData *= N    # compensate for factor
        return transformedData

    ### YOUR CODE ENDS HERE ###

def IMDCT(data,a,b):
    
    ### YOUR CODE STARTS HERE ###
    return MDCT( data , a, b, True) # CHANGE THIS
    ### YOUR CODE ENDS HERE ###

#-----------------------------------------------------------------------------



#Testing code
if __name__ == "__main__":
    
    ### YOUR TESTING CODE STARTS HERE ###
    print "\n\n\nPROBLEM 1a/b."
    blockSize = 4
    x = np.array([0,1,2,3,4,4,4,4,3,1,-1,-3])
    N = x.size
    output = np.array([])
    prevBlock = np.array([0,0,0,0])
    prevOutputBlock = np.array([0,0,0,0])
    for i in range(N/blockSize+1):
        if i==N/blockSize:
            currBlock = np.zeros_like(prevBlock)
        else:
            pos = i*blockSize
            currBlock = x[pos:pos+blockSize]
        print "\n\n\nset # " + str(i+1)
        fullBlock = np.concatenate([prevBlock, currBlock])
        print "\nmdct input"
        print fullBlock
        fullBlock = MDCTslow(fullBlock,4,4)
        print "\nmdct output"
        print fullBlock
        fullBlock = MDCTslow(fullBlock,4,4,1) * 0.5
        print "\nimdct output"
        print fullBlock
        outputBlock = prevOutputBlock + fullBlock[0:4]
        print "\noutput block"
        print outputBlock
        output = np.append(output,outputBlock)
        prevOutputBlock = fullBlock[4:8]
        prevBlock = currBlock
    print "\n Final output"
    print np.around(output,0)

    print "Each individual block of MDCT/IMDCT output is not equal to the input block\n",\
    "since it contains an alias term that cancels on doing overlap and add to give us\n",\
    "our input signal back"

    print "\n\n\nPROBLEM 1b."
    print "The input block was zero-padded at the beginning and end to get the complete\n",\
    "signal into the MDCT\n"

    print "There is a 4 sample delay in this example"

    print "\n\n\nPROBLEM 1c."
    print "\nCalculating slow MDCT...."
    size = 4096
    example = np.zeros(size)
    t1 = time.time()
#    transformedExample = MDCTslow(example,size/2,size/2)
#    example = MDCTslow(transformedExample,size/2,size/2,1)
    t2 = time.time()
    print "\nTime taken for slow implementation:", t2-t1, "s"

    print "\nCalculating fast MDCT...."
    example = np.zeros(size)
    t1 = time.time()
    transformedExample = MDCT(example,size/2,size/2)
    example = MDCT(transformedExample,size/2,size/2,1)
    t2 = time.time()
    print "\nTime taken for fast implementation:", t2-t1, "s"



    ### YOUR TESTING CODE ENDS HERE ###
    # 1.e
    print "\n\n\nPROBLEM 1e."
    n = np.linspace(0,1023,1024)
    x = np.cos(2*np.pi*4000/44100*n)
    x_sin = window.SineWindow(x)
    fftx_sin = np.fft.fft(x_sin)
    x_hanning = window.HanningWindow(x)
    fftx_hanning = np.fft.fft(x_hanning)
    mdctx_sin = MDCT(x_sin,512,512)

    N = 1024
    # window2 calculated once separately
    w2_sin = 0.5
    w2_hanning = 0.375
    
    mdctx_sin *= N/2

    spl_fftx_sin =  96 + 10*np.log10(4.0/(N*N*w2_sin) * fftx_sin * fftx_sin)
    spl_fftx_hanning = 96 + 10*np.log10(4.0/(N*N*w2_hanning) * fftx_hanning * fftx_hanning)
    spl_mdctx_sin = 96 + 10*np.log10(8.0/(N*N*w2_sin) * mdctx_sin * mdctx_sin)
    
    plt.hold(True)
    plotFFTSin, = plt.plot(spl_fftx_sin[0:N/2])
    plotFFTHanning, = plt.plot(spl_fftx_hanning[0:N/2])
    plotMDCTSin, = plt.plot(spl_mdctx_sin[0:N/2])
    plt.legend([plotFFTSin, plotFFTHanning, plotMDCTSin], ["SPL FFT Sin Window", "SPL FFT Hanning window", "SPL MDCT Sin window"])
    plt.show()


    print "FFT has better frequency using the same window. This explains why FFT",\
    "is better for peak detection instead the MDCT. Hanning window is better at",\
    "FFT analysis instead of a Sine window because it has a narrower main lobe"
