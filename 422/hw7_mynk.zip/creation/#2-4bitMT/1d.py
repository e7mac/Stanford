from pcmfile import *
from quantize import *

# create the audio file objects of the appropriate audioFile type
files = ["tonal.wav","speech.wav","attacks.wav"]
for file in files:
    inFile= PCMFile(file)
    outFile = PCMFile(file + "_output.wav")

    # open input file and get its coding parameters
    codingParams= inFile.OpenForReading()

    # set additional coding parameters that are needed for encoding/decoding
    codingParams.nSamplesPerBlock = 16

    # open the output file for writing, passing needed format/data parameters
    outFile.OpenForWriting(codingParams)

    # uniform
    ## Read the input file and pass its data to the output file to be written
    while True:
        data=inFile.ReadDataBlock(codingParams)
        if not data: break  # we hit the end of the input file
        nBits = 4
        for iCh in range(codingParams.nChannels):
            data[iCh] = vDequantizeUniform( vQuantizeUniform(data[iCh], nBits), nBits)
        outFile.WriteDataBlock(data,codingParams)
    ## end loop over reading/writing the blocks

    # fp
    # Read the input file and pass its data to the output file to be written
    #while True:
    #    data=inFile.ReadDataBlock(codingParams)
    #    if not data: break  # we hit the end of the input file
    #    for iCh in range(codingParams.nChannels):
    #        for sample in range(len(data[iCh])):
    #            scale = ScaleFactor(data[iCh][sample])
    #            data[iCh][sample] = DequantizeFP( scale, MantissaFP(data[iCh][sample], scale))
    #    outFile.WriteDataBlock(data,codingParams)
    # end loop over reading/writing the blocks

    # bfp
    # Read the input file and pass its data to the output file to be written
    #while True:
    #    data=inFile.ReadDataBlock(codingParams)
    #    if not data: break  # we hit the end of the input file
    #    for iCh in range(codingParams.nChannels):
    #        scale = 100
    #        for sample in range(len(data[iCh])):
    #            s = ScaleFactor(data[iCh])
    #            if s<scale:
    #                scale = s
    #        for sample in range(len(data[iCh])):
    #            data[iCh][sample] = Dequantize( scale, Mantissa(data[iCh][sample], scale))
    #    outFile.WriteDataBlock(data,codingParams)
    # end loop over reading/writing the blocks


    # close the files
    inFile.Close(codingParams)
    outFile.Close(codingParams)


