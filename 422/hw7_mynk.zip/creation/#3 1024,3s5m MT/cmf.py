import numpy as np

if __name__ == "__main__":
    n = np.array([-3,-2,-1,0,1,2,3])
    w = np.sin(np.pi*(n+3.5)/7.0)
    s = np.sinc(n/2)
    p = w * s
    p = np.around(p,0)
    print 'p[z] = '
    print p
    print 'p[0] = 1 and p[even] = 0 thus satisfying the power complementarity condition'
    f = np.fft.fft(p)
    f = np.real(f)
    f = np.around(f,0)
    min = np.min(f)
    f += np.abs(min)
    f *= 1 / (1 + np.abs(min))
    print 'scaled FourierTransform = '
    print f
