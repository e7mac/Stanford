import numpy as np
import window
import matplotlib.pyplot as plt
import normalization
import mdct
import psychoac


pi = np.pi
cos = np.cos
fs = 48000
N = 1024
n = np.linspace(0, N-1, N)
a = [0.45, 0.15, 0.15, 0.10, 0.06, 0.05]
x = a[0]*cos(2*pi*440.*n/fs) + a[1]*cos(2*pi*550.*n/fs) + a[2]*cos(2*pi*660.*n/fs) + a[3]*cos(2*pi*880.*n/fs) + a[4]*cos(2*pi*4400.*n/fs) + a[5]*cos(2*pi*8800.*n/fs)
x_hanning = window.HanningWindow(x)
w2_hanning = 0.375
x_sine = window.SineWindow(x)
w2_sine = 0.5
mdctx = np.array(mdct.MDCT(x_sine,N/2,N/2))


dftx = np.fft.fft(x_hanning)[0:N/2]
binFreqs = (np.linspace(0, pi, len(dftx)) * fs) / (2 * pi)
spl_dftx = normalization.SPL_dft(dftx,window.HanningWindow(np.ones(N)))
spl_mdctx = normalization.SPL_mdct(mdctx,window.HanningWindow(np.ones(N)))

barks = psychoac.Bark(binFreqs)

masterMasker = np.zeros_like(binFreqs)

# get peaks
for i in range(N/2-3):
    if spl_dftx[i+1]>spl_dftx[i] and spl_dftx[i+1]>spl_dftx[i+2]:
        intensity_peak = psychoac.Intensity(spl_dftx[i+1])
        intensity_peak_less = psychoac.Intensity(spl_dftx[i])
        intensity_peak_more = psychoac.Intensity(spl_dftx[i+2])
        intensity_sum = intensity_peak + intensity_peak_less + intensity_peak_more
        spl_intensity = psychoac.SPL(intensity_sum)
        
        frequency = ( (intensity_peak * binFreqs[i+1]) + (intensity_peak_less * binFreqs[i]) + (intensity_peak_more * binFreqs[i+2]) ) / (intensity_peak + intensity_peak_less + intensity_peak_more)
        if N == 1024:
            masker = psychoac.Masker(frequency, spl_intensity, True)
            maskerIntensity = masker.vIntensityAtBark(barks)
            masterMasker += maskerIntensity
            maskerSPL = psychoac.SPL(maskerIntensity)

masterMaskerSPL = psychoac.SPL(masterMasker)
sfBands = psychoac.ScaleFactorBands( psychoac.AssignMDCTLinesFromFreqLimits(N/2, fs) )
mdctBinFreqs = (np.arange(N/2) + 0.5) / (N/2) * (fs * 0.5)
smrs = psychoac.CalcSMRs(x, mdctx, 0, fs, sfBands)


def BitAllocUniform(bitBudget, maxMantBits, nBands, nLines, SMR):
    """
    Return a hard-coded vector that, in the case of the signal use in HW#4,
    gives the allocation of mantissa bits in each scale factor band when
    bits are uniformely distributed for the mantissas.

    bitBudget is total number of mantissa bits to allocate
    maxMantBits is max mantissa bits that can be allocated per line
    nBands is total number of scale factor bands
    nLines[nBands] is number of lines in each scale factor band
    SMR[nBands] is signal-to-mask ratio in each scale factor band

    """
    
    nLines = np.array(nLines)
    SMR = np.array(SMR)
    totalLines = np.sum(nLines)
    bitAllocVec = np.zeros(nBands) + bitBudget / totalLines
    
    return sanity_check(bitAllocVec,maxMantBits)

def BitAllocConstSNR(bitBudget, maxMantBits, nBands, nLines, SMR):
    """
    Return a hard-coded vector that, in the case of the signal use in HW#4,
    gives the allocation of mantissa bits in each scale factor band when
    bits are distributed for the mantissas to try and keep a constant 
    quantization noise floor (assuming a noise floor 6 dB per bit below 
    the peak SPL line in the scale factor band).
    """
    # ensure numpy
    nLines = np.array(nLines)
    SMR = np.array(SMR)

    
    # get maxSPL
    startBandIndex = 0
    endBandIndex = 0
    maxSPL = np.zeros(nBands)
    for i in range(int(nBands) - 1):
        endBandIndex = startBandIndex + nLines[i]
        maxSPL[i] = np.amax(spl_mdctx[startBandIndex:endBandIndex+1])
        startBandIndex = endBandIndex

    noiseFloor = np.array(maxSPL)
    # allocate bits
    bitAllocVec = np.zeros(nBands)

    while (bitBudget > 0):
        maxNoiseIndex = noiseFloor.argmax()
        if ( bitBudget < nLines[maxNoiseIndex]):
            break
#        print maxNoiseIndex
        bitAllocVec[maxNoiseIndex] += 1
        noiseFloor[maxNoiseIndex] -= 6
        bitBudget -= nLines[maxNoiseIndex]

    # remove 1s
    for i in range(int(nBands)):
        if bitAllocVec[i] == 1:
            bitAllocVec[i] = 0



    #print
#    plt.figure()
#    plt.semilogx(mdctBinFreqs, spl_mdctx, 'b.')
    for i in range(int(nBands) - 2):
        band = sfBands.lowerLine[i]
        plt.vlines(mdctBinFreqs[band],-80,100,linestyle='dotted')
        plt.hlines(maxSPL[i],mdctBinFreqs[sfBands.lowerLine[i]],mdctBinFreqs[sfBands.lowerLine[i+1]],color='r')
        plt.hlines(maxSPL[i] - 6*bitAllocVec[i],mdctBinFreqs[sfBands.lowerLine[i]],mdctBinFreqs[sfBands.lowerLine[i+1]],color='g')

#    plt.show()
    return sanity_check(bitAllocVec,maxMantBits)

def BitAllocConstMNR(bitBudget, maxMantBits, nBands, nLines, SMR):
    """
    Return a hard-coded vector that, in the case of the signal use in HW#4,
    gives the allocation of mantissa bits in each scale factor band when
    bits are distributed for the mantissas to try and keep the quantization
    noise floor a constant distance below (or above, if bit starved) the
    masked threshold curve (assuming a quantization noise floor 6 dB per
    bit below the peak SPL line in the scale factor band).
    """
    # ensure numpy
    nLines = np.array(nLines)
    SMR = np.array(SMR)
    
    
    # get maxSPL
    startBandIndex = 0
    endBandIndex = 0
    maxSPL = np.zeros(nBands)
    for i in range(int(nBands) - 1):
        endBandIndex = startBandIndex + nLines[i]
        maxSPL[i] = np.amax(spl_mdctx[startBandIndex:endBandIndex+1])
        startBandIndex = endBandIndex
    
    # TODO : fix
#    SMR = np.append(SMR,0)
    noiseFloor = SMR
    # allocate bits
    bitAllocVec = np.zeros(nBands)
#    for i in range(1):
    while (bitBudget > 0):
        maxNoiseIndex = noiseFloor.argmax()
        if ( bitBudget < nLines[maxNoiseIndex]):
            break

        bitAllocVec[maxNoiseIndex] += 1
        noiseFloor[maxNoiseIndex] -= 6
        bitBudget -= nLines[maxNoiseIndex]

    # remove 1s
    for i in range(int(nBands)):
        if bitAllocVec[i] == 1:
            bitAllocVec[i] = 0
    

    #print
#    plt.figure()
#    plt.semilogx(mdctBinFreqs, spl_mdctx, 'b.')
    for i in range(int(nBands) - 2):
        band = sfBands.lowerLine[i]
        plt.vlines(mdctBinFreqs[band],-80,100,linestyle='dotted')
        plt.hlines(maxSPL[i],mdctBinFreqs[sfBands.lowerLine[i]],mdctBinFreqs[sfBands.lowerLine[i+1]],color='r')
        plt.hlines(maxSPL[i] - 6*bitAllocVec[i],mdctBinFreqs[sfBands.lowerLine[i]],mdctBinFreqs[sfBands.lowerLine[i+1]],color='g')
        plt.hlines(SMR[i],mdctBinFreqs[sfBands.lowerLine[i]],mdctBinFreqs[sfBands.lowerLine[i+1]],color='y')
#    plt.show()

    return sanity_check(bitAllocVec,maxMantBits)

# Question 1.c)
def BitAlloc(bitBudget, maxMantBits, nBands, nLines, SMR):
    """
    Allocates bits to scale factor bands so as to flatten the NMR across the spectrum
    
       Arguments:
           bitBudget is total number of mantissa bits to allocate
           maxMantBits is max mantissa bits that can be allocated per line
           nBands is total number of scale factor bands
           nLines[nBands] is number of lines in each scale factor band
           SMR[nBands] is signal-to-mask ratio in each scale factor band
    
        Return:
            bits[nBands] is number of bits allocated to each scale factor band
    
        Logic:
           Maximizing SMR over blook gives optimization result that:
               R(i) = P/N + (1 bit/ 6 dB) * (SMR[i] - avgSMR)
           where P is the pool of bits for mantissas and N is number of bands
           This result needs to be adjusted if any R(i) goes below 2 (in which
           case we set R(i)=0) or if any R(i) goes above maxMantBits (in
           which case we set R(i)=maxMantBits).  (Note: 1 Mantissa bit is
           equivalent to 0 mantissa bits when you are using a midtread quantizer.)
           We will not bother to worry about slight variations in bit budget due
           rounding of the above equation to integer values of R(i).
    """
    return BitAllocConstMNR(bitBudget, maxMantBits, nBands, nLines, SMR)

#-----------------------------------------------------------------------------

def sanity_check(vBitAlloc,maxMantBits):
    # remove 1s and negatives
    for i in range(len(vBitAlloc)):
        if vBitAlloc[i] < 2:
            vBitAlloc[i] = 0
    # clamp to max
    for i in range(len(vBitAlloc)):
        if vBitAlloc[i] > maxMantBits:
            vBitAlloc[i] = maxMantBits
    return vBitAlloc.astype(int) 






#Testing code
if __name__ == "__main__":
    
    pass # TO REPLACE WITH YOUR CODE
