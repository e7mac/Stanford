import numpy as np
import window
import matplotlib.pyplot as plt
import normalization
import mdct

def SPL(intensity):
    """
    Returns the SPL corresponding to intensity (in units where 1 implies 96dB)
    """
    intensity = np.array(intensity)
    spl = 96.0 + (10.0 * np.log10(intensity))
    spl = np.maximum(spl,-30.)
    return spl

def Intensity(spl): 
    """
    Returns the intensity (in units of the reference intensity level) for SPL spl
    """
    spl = np.array(spl)
    intensity = np.power(10.0, ((spl - 96.0) / 10.0))
    return intensity


def Thresh(f): 
    """Returns the threshold in quiet measured in SPL at frequency f (in Hz)""" 

    f = np.maximum(f, 10.0)
    fKhz = f / 1000.0
    afdB = 3.64 * np.power(fKhz, -0.8) - 6.5 * np.exp(-0.6 * np.power((fKhz - 3.3), 2.0)) + np.power(10.0, -3.0) * np.power(fKhz, 4.0)
    return afdB


def Bark(f): 
    """Returns the bark-scale frequency for input frequency f (in Hz) """
    f = np.array(f)
    fKhz = f / 1000.0
    zBark = 13 * np.arctan(0.76 * fKhz) + 3.5 * np.arctan((fKhz / 7.5) ** 2)
    return zBark


class Masker: 
    """ 
    a Masker whose masking curve drops linearly in Bark beyond 0.5 Bark from the 
    masker frequency
    """
    
    def __init__(self,f,SPL,isTonal=True): 
        """
        initialized with the frequency and SPL of a masker and whether or not 
        it is Tonal
        """
        self.freq = f
        self.z = Bark(self.freq)
        self.spl = SPL
        self.isTonal = isTonal

    def IntensityAtFreq(self,freq): 
        """The intensity of this masker at frequency freq"""
        return IntensityAtBark(self, Bark(freq))

    def IntensityAtBark(self,z): 
        """The intensity of this masker at Bark location z""" 
        dz = z - self.z
        if dz >= -0.5 and dz <= 0.5:
            spl = 0.0
        elif dz < -0.5:
            spl = -27.0 * (np.absolute(dz) - 0.5)
        elif dz > 0.5:
            spl = -27.0 + 0.367 * np.maximum(self.spl - 40.0, 0.0) * (np.absolute(dz) - 0.5)
        if self.isTonal:
            spl -= (14.5)
        else:
            spl -= 5.5    
        spl += self.spl
        intensity = Intensity(spl)
        return intensity


    def vIntensityAtBark(self,zVec): 
        """The intensity of this masker at vector of Bark locations zVec""" 
        vDz = zVec - self.z
        vSPL = np.zeros_like(vDz)
        
        posSlope = np.greater(vDz, 0.5).astype(int)
        negSlope = np.less(vDz, -0.5).astype(int)
        
        vSPLPosSlope = posSlope * (-27.0 + 0.367 * np.maximum(self.spl - 40.0, 0.0)) * (np.absolute(vDz) - 0.5)
        vSPLNegSlope = negSlope * (-27.0 * (np.absolute(vDz) - 0.5))
        
        vSPL = vSPLPosSlope + vSPLNegSlope
        if self.isTonal:
            vSPL -= 14.5
        else:
            vSPL -= 5.5
        vSPL += self.spl
        vInt = Intensity(vSPL)
        return vInt

# Default data for 25 scale factor bands based on the traditional 25 critical bands
cbFreqLimits = [100.0, 200.0, 300.0, 400.0, 510.0, 630.0, 770.0, 920.0, 1080.0, 1270.0, 1480.0, 1720.0, 2000.0, 2320.0, 2700.0, 3150.0, 3700.0, 4400.0, 5300.0, 6400.0, 7700.0, 9500.0, 12000.0, 15500.0, 24000.0]
                 
def AssignMDCTLinesFromFreqLimits(nMDCTLines, sampleRate, flimit = cbFreqLimits): 
    """
    Assigns MDCT lines to scale factor bands for given sample rate and number 
    of MDCT lines using predefined frequency band cutoffs passed as an array 
    in flimit (in units of Hz). If flimit isn't passed it uses the traditional 
    25 Zwicker & Fastl critical bands as scale factor bands.
    """
    binFreqs = (np.arange(nMDCTLines) + 0.5) / nMDCTLines * (sampleRate * 0.5)
    currentBin = 0
    count = 0
    scaleFactorBands = []
    for freq in binFreqs:
        if freq < flimit[currentBin]:
            count += 1
        else:
            scaleFactorBands.append(count)
            count = 1
            currentBin += 1
    return np.array(scaleFactorBands)
    
class ScaleFactorBands:
    """
    A set of scale factor bands (each of which will share a scale factor and a 
    mantissa bit allocation) and associated MDCT line mappings.
    
    Instances know the number of bands nBands; the upper and lower limits for 
    each band lowerLimit[i in range(nBands)], upperLimit[i in range(nBands)]; 
    and the number of lines in each band nLines[i in range(nBands)] 
    """
    
    def __init__(self,nLines): 
        """
        Assigns MDCT lines to scale factor bands based on a vector of the number 
        of lines in each band
        """
        self.nBands = np.size(np.array(nLines))
        self.lowerLine = [0]
        self.upperLine = []
        self.nLines = nLines
        
        upperLimit = 0
        lowerLimit = 0
        for line in nLines:
            upperLimit += line
            self.upperLine.append(upperLimit)

        self.upperLine = np.array(self.upperLine)
        self.lowerLine = np.append(self.lowerLine, self.upperLine[0:len(self.lowerLine) - 2])                
        self.upperLine = self.upperLine - 1

def CalcSMRs(data, MDCTdata, MDCTscale, sampleRate, sfBands): 
    """
    Set SMR for each critical band in sfBands.
    
    Arguments:
                data:       is an array of N time domain samples 
                MDCTdata:   is an array of N/2 MDCT frequency lines for the data
                            in data which have been scaled up by a factor 
                            of 2^MDCTscale 
                MDCTscale:  is an overall scale factor for the set of MDCT 
                            frequency lines 
                sampleRate: is the sampling rate of the time domain samples 
                sfBands:    points to information about which MDCT frequency lines
                            are in which scale factor band 
                            
    Returns:
                SMR[sfBands.nBands] is the maximum signal-to-mask ratio in each 
                                    scale factor band
    
    Logic: 
                Performs an FFT of data[N] and identifies tonal and noise maskers. 
                Sums their masking curves with the hearing threshold at each MDCT 
                frequency location to the calculate absolute threshold at those 
                points. Then determines the maximum signal-to-mask ratio within 
                each critical band and returns that result in the SMR[] array.
    """

    N = len(data)
    x_hanning = window.HanningWindow(data)
    w2_hanning = 0.375
    dftx = np.fft.fft(x_hanning)[0:N/2]
    binFreqs = (np.linspace(0, np.pi, len(dftx)) * sampleRate) / (2 * np.pi)
    
    mdctBinFreqs = (np.arange(N/2) + 0.5) / (N/2) * (sampleRate * 0.5)
    spl_dftx = normalization.SPL_dft(dftx,window.HanningWindow(np.ones(N)))
    MDCTdata_spl = normalization.SPL_mdct(MDCTdata,window.SineWindow(np.ones(N)))
    
    tonalMaskers = []
    noiseMaskers = []
    tonalMaskerPeaks = []
    
    binThresholds = Thresh(mdctBinFreqs)
    
    # get tonal maskers
    for i in range(N/2-3):
        if spl_dftx[i+1]>spl_dftx[i] and spl_dftx[i+1]>spl_dftx[i+2]:
            intensity_peak = Intensity(spl_dftx[i+1])
            intensity_peak_less = Intensity(spl_dftx[i])
            intensity_peak_more = Intensity(spl_dftx[i+2])
            intensity_sum = intensity_peak + intensity_peak_less + intensity_peak_more
            spl_intensity = SPL(intensity_sum)
            frequency = ( (intensity_peak * binFreqs[i+1]) + (intensity_peak_less * binFreqs[i]) + (intensity_peak_more * binFreqs[i+2]) ) / (intensity_peak + intensity_peak_less + intensity_peak_more)
            
            masker = Masker(frequency, spl_intensity, True)
            tonalMaskers.append(masker)
            tonalMaskerPeaks.append(frequency)


    # get noise maskers
    for i in range(sfBands.nBands):

        peakInBand = False
        lowerBandFreq = mdctBinFreqs[sfBands.lowerLine[i]]
        upperBandFreq = mdctBinFreqs[sfBands.upperLine[i]]

        for peak in tonalMaskerPeaks:
            if peak<upperBandFreq and peak>lowerBandFreq:
                peakInBand = True
    
        if not peakInBand:
            intensity_peak = Intensity(spl_dftx[i+1])
            intensity_peak_less = Intensity(spl_dftx[i])
            intensity_peak_more = Intensity(spl_dftx[i+2])
            intensity_sum = intensity_peak + intensity_peak_less + intensity_peak_more
            spl_intensity = SPL(intensity_sum)
            frequency = ( (intensity_peak * binFreqs[i+1]) + (intensity_peak_less * binFreqs[i]) + (intensity_peak_more * binFreqs[i+2]) ) / (intensity_peak + intensity_peak_less + intensity_peak_more)
            masker = Masker(frequency, spl_intensity, False)
            noiseMaskers.append(masker)

    binBarks = Bark(mdctBinFreqs)

                    
    # add all masker intensities
    masterMasker = np.zeros_like(mdctBinFreqs)
                    
    for masker in tonalMaskers:
        maskerIntensity = masker.vIntensityAtBark(binBarks)
        masterMasker += maskerIntensity
    for masker in noiseMaskers:
        maskerIntensity = masker.vIntensityAtBark(binBarks)
        masterMasker += maskerIntensity

    masterMasker += Intensity(binThresholds)
    masterMasker = SPL(masterMasker)

    # get SMRs
    SMRs = []

    for i in range(sfBands.nBands):
        bandLowerMDCTIndex = sfBands.lowerLine[i]
        bandUpperMDCTIndex = sfBands.upperLine[i]

        bandMasterMasker = masterMasker[bandLowerMDCTIndex:bandUpperMDCTIndex]

        bandDataMDCT = MDCTdata_spl[bandLowerMDCTIndex:bandUpperMDCTIndex]

        bandSMR = bandDataMDCT - bandMasterMasker
        SMRs.append(np.amax(bandSMR))

    return np.array(SMRs)

#-----------------------------------------------------------------------------

#Testing code
if __name__ == "__main__":
    pass