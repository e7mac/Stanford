"""
quantize.py -- routines to quantize and dequantize floating point values between
-1.0 and 1.0 (" signed fractions ")
"""

### ADD YOUR CODE AT THE SPECIFIED LOCATIONS ###

import numpy as np

### Problem 1.a.i ###
def QuantizeUniform(aNum,nBits):
    """
    Uniformly quantize signed fraction aNum with nBits
    """
    #Notes:
    #The overload level of the quantizer should be 1.0
    
    ### YOUR CODE STARTS HERE ###
    if (aNum>=0):
        s=0
    else:
        s=1
    overload = 1;
    if (abs(aNum)>=overload):
        code = (1<<nBits-1) - 1
    else:
        code = int((((1<<nBits)-1)*abs(aNum)+1.0)/2.0)
    aQuantizedNum = (s<<nBits-1) + code
    ### YOUR CODE ENDS HERE ###
    return aQuantizedNum

### Problem 1.a.i ###
def DequantizeUniform(aQuantizedNum,nBits):
    """
    Uniformly dequantizes nBits-long number aQuantizedNum into a signed fraction
    """
    
    ### YOUR CODE STARTS HERE ###
    s = aQuantizedNum>>nBits-1
    code = ((1<<nBits-1)-1)&aQuantizedNum
    if (s == 0):
        sign = 1
    else:
        sign = -1
    number = float(code<<1)/((1<<nBits)-1)
    aNum = sign*number
    ### YOUR CODE ENDS HERE ###
    
    return aNum

### Problem 1.a.ii ###
def vQuantizeUniform(aNumVec, nBits):
    """
    Uniformly quantize vector aNumberVec of signed fractions with nBits
    """
    
    #Notes:
    #Make sure to vectorize properly your function as specified in the homework instructions
    ### YOUR CODE STARTS HERE ###
    
    aNumArray = np.array(aNumVec)
    
    # clamp values
    aNumArray = np.minimum(aNumArray,1)
    aNumArray = np.maximum(aNumArray,-1)

    # get signs
    absANumArray = np.abs(aNumArray)
    isNegative = absANumArray - aNumArray
    s = np.where(isNegative,1,0)
    
    # get code
    nonOverloadCode = ((((1<<nBits)-1)*absANumArray+1)/2).astype(int)
    code = np.where(absANumArray>=1,(1<<nBits-1) - 1,nonOverloadCode)
    aQuantizedNumVec = np.left_shift(s,nBits-1) + code
    ### YOUR CODE ENDS HERE ###
    
    return aQuantizedNumVec.astype(np.uint)

### Problem 1.a.ii ###
def vDequantizeUniform(aQuantizedNumVec, nBits):
    """
    Uniformly dequantizes vector of nBits-long numbers aQuantizedNumVec into vector of  signed fractions
    """
    
    aQuantizedNumArray = np.array(aQuantizedNumVec) # REMOVE THIS LINE WHEN YOUR FUNCTION IS DONE
    
    ### YOUR CODE STARTS HERE ###
    s = np.right_shift(aQuantizedNumArray,nBits-1)
    code = np.bitwise_and(((1<<nBits-1)-1),aQuantizedNumArray)
    sign = np.where(s,-1,1)
    number = np.divide((np.left_shift(code,1)).astype(float),(1<<nBits)-1)
    aNumVec = np.multiply(sign,number)
    ### YOUR CODE ENDS HERE ###
    return aNumVec

### Problem 1.b ###
def ScaleFactor(aNum, nScaleBits=3, nMantBits=5):
    """
    Return the floating-point scale factor for a  signed fraction aNum given nScaleBits scale bits and nMantBits mantissa bits
    """
    #Notes:
    #The scale factor should be the number of leading zeros
    ### YOUR CODE STARTS HERE ###
    aNum = np.max(np.array(aNum))
    R = nScaleBits + nMantBits
    nBitsUniform = (1<<nScaleBits) - 1 + nMantBits;
    uniformQ = QuantizeUniform(aNum,nBitsUniform)
    s = uniformQ>>(nBitsUniform-1)
    code = ((1<<nBitsUniform-1)-1)&uniformQ
    leadingZeros = nBitsUniform - np.ceil(np.log2(code+1)) - 1
    scale = int(min(leadingZeros, (1<<nScaleBits)-1))
    ### YOUR CODE ENDS HERE ###
    return scale

### Problem 1.b ###
def MantissaFP(aNum, scale, nScaleBits=3, nMantBits=5):
    """
    Return the floating-point mantissa for a  signed fraction aNum given nScaleBits scale bits and nMantBits mantissa bits
    """
    ### YOUR CODE STARTS HERE ###
    Rs = nScaleBits
    Rm = nMantBits
    R = Rs + Rm
    nBitsUniform = (1<<Rs) - 1 + Rm;
    uniformQ = QuantizeUniform(aNum,nBitsUniform)
    s = uniformQ>>(nBitsUniform-1)
    code = ((1<<nBitsUniform-1)-1)&uniformQ
    numBitsInCode = np.ceil(np.log2(code+1)) - 1
    leadingZeros = nBitsUniform - np.ceil(np.log2(code+1)) - 1

    if (scale == ((1<<Rs)-1)):
        partCode = code
    else:
        bitsToMove = int(nBitsUniform - 1 - scale - 1 - nMantBits + 1)
        partCode = (code >> (bitsToMove))&((1<<Rm-1)-1)
    mantissa = (s<<nMantBits-1) + partCode
    ### YOUR CODE ENDS HERE ###
    return mantissa

### Problem 1.b ###
def DequantizeFP(scale, mantissa, nScaleBits=3, nMantBits=5):
    """
    Returns a  signed fraction for floating-point scale and mantissa given specified scale and mantissa bits
    """
    
    ### YOUR CODE STARTS HERE ###
    
    # TODO: check this
    Rs = nScaleBits
    Rm = nMantBits
    R = (1<<Rs) - 1 + Rm;
    s = mantissa >> (nMantBits - 1)
    
    
    onlyMantissa = ((1<<nMantBits-1)-1) & mantissa
#    print 'mant'
#    print np.binary_repr(onlyMantissa)
#    print 'scale'
#    print scale
    # TODO : fix this
    # handle this case separately
    if (scale == ((1<<Rs)-1) ):
        partCode = onlyMantissa
    else:
        partCode = (1<<nMantBits-1) + onlyMantissa

    if (scale < ((1<<Rs)-1) ):
        remainderBits = R - Rm - scale - 1
        if remainderBits!=0:
            partCode = (int(partCode)<<remainderBits) + (1<<(remainderBits-1))

    code = (s<<R-1) + partCode
    aNum = DequantizeUniform(code,R)
    ### YOUR CODE ENDS HERE ###
    
    return float(aNum)

### Problem 1.c.i ###
def Mantissa(aNum, scale, nScaleBits=3, nMantBits=5):
    """
    Return the block floating-point mantissa for a  signed fraction aNum given nScaleBits scale bits and nMantBits mantissa bits
    """
    
    ### YOUR CODE STARTS HERE ###
    R = nScaleBits + nMantBits
    Rm = nMantBits
    nBitsUniform = (1<<nScaleBits) - 1 + nMantBits;
    uniformQ = QuantizeUniform(aNum,nBitsUniform)
    s = uniformQ>>(nBitsUniform-1)
    code = ((1<<nBitsUniform-1)-1)&uniformQ
    bitsToMove = int(nBitsUniform - 1 - scale - nMantBits + 1)
    partCode = (code >> (bitsToMove))&((1<<Rm-1)-1)
    mantissa = (s<<nMantBits-1) + partCode    
    ### YOUR CODE ENDS HERE ###
    
    return mantissa

### Problem 1.c.i ###
def Dequantize(scale, mantissa, nScaleBits=3, nMantBits=5):
    """
    Returns a  signed fraction for block floating-point scale and mantissa given specified scale and mantissa bits
    """
    
    
    
    ### YOUR CODE STARTS HERE ###
    Rs = nScaleBits
    Rm = nMantBits
    R = (1<<Rs) - 1 + Rm;
    s = mantissa >> (nMantBits - 1)
    
    onlyMantissa = ((1<<nMantBits-1)-1) & mantissa
    partCode = onlyMantissa
    if (scale < ((1<<Rs)-1) ) and (mantissa&((1<<Rm-1)-1))!=0:
        remainderBits = R  - Rm - scale
        partCode = (int(partCode)<<remainderBits) + (1<<(remainderBits-1))

    code = (s<<R-1) + partCode

    aNum = DequantizeUniform(code,R)
    ### YOUR CODE ENDS HERE ###
    return aNum

### Problem 1.c.ii ###
def vMantissa(aNumVec, scale, nScaleBits=3, nMantBits=5):
    """
    Return a vector of block floating-point mantissas for a vector of  signed fractions aNum given nScaleBits scale bits and nMantBits mantissa bits
    """
    
        
    ### YOUR CODE STARTS HERE ###
    R = nScaleBits + nMantBits
    Rm = nMantBits
    nBitsUniform = (1<<nScaleBits) - 1 + nMantBits;
    uniformQVec = np.array(vQuantizeUniform(aNumVec,nBitsUniform))
    s = np.right_shift(uniformQVec,(nBitsUniform-1))
    code = np.bitwise_and(((1<<nBitsUniform-1)-1),uniformQVec)
    bitsToMove = int(nBitsUniform - 1 - scale - nMantBits + 1)
    partCode = np.bitwise_and(np.right_shift(code, bitsToMove), (1<<Rm-1)-1 )
    mantissaVec = np.left_shift(s,nMantBits-1) + partCode
    ### YOUR CODE ENDS HERE ###
    return mantissaVec.astype(np.uint)

### Problem 1.c.ii ###
def vDequantize(scale, mantissaVec, nScaleBits=3, nMantBits=5):
    """
    Returns a vector of  signed fractions for block floating-point scale and vector of block floating-point mantissas given specified scale and mantissa bits
    """
    
    
    ### YOUR CODE STARTS HERE ###
    mantissaVec = np.array(mantissaVec)
    Rs = nScaleBits
    Rm = nMantBits
    R = (1<<Rs) - 1 + Rm;
    s = np.right_shift(mantissaVec,nMantBits - 1)
    
    onlyMantissa = np.bitwise_and(((1<<nMantBits-1)-1), mantissaVec)
    partCode = onlyMantissa
    
    if (scale < ((1<<Rs)-1) ):
        remainderBits = R - (Rm + scale)
        partCode = partCode << (remainderBits)
        mantissaZero = np.where(mantissaVec,1,0)
        partCode[mantissaZero] = partCode[mantissaZero] + (1<<( remainderBits -1))

    signFlip = np.where(mantissaVec < (1<<(nMantBits-1)),False,True)
    partCode[signFlip] = (1<<(R-1)) + partCode[signFlip]

    code = partCode
    aNumVec = vDequantizeUniform(code.astype(int),R)
    aNumVec = np.where(mantissaVec,aNumVec,0)
            
    return aNumVec.astype(np.float)

#-----------------------------------------------------------------------------

#Testing code
if __name__ == "__main__":
    
    ### YOUR TESTING CODE STARTS HERE ###
    
    pass # THIS DOES NOTHING
    
    ### YOUR TESTING CODE ENDS HERE ###
    
