from bitalloc import *

fs = 48000.
dataRate = 256  . * 1000
N = 1024.
bitBudget = dataRate / fs * N / 2. - (8*25) - 4
maxMantBits = 0.
nBands = 24.
nLines = sfBands.nLines
SMR = smrs

#print BitAllocUniform(bitBudget, maxMantBits, nBands, nLines, SMR)
#print BitAllocConstSNR(bitBudget, maxMantBits, nBands, nLines, SMR)
print BitAllocConstMNR(bitBudget, maxMantBits, nBands, nLines, SMR)
