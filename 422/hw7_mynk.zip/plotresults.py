import pylab as plt
import numpy as np

tests = ['Tonal Sound','Speech Sound','Attacks (Castanet)']
people = ['me','maddie','colin','romain','jen']
coders = ['4uniform','3s5mFP','4bit.N1024','3s5m.N1024','128','256']

experienced = [0, 2, 4]
non_experienced = [1, 3]

result = np.zeros((3,5,6))

# tonal
# me
result[0][0][0] = -4
result[0][0][1] = -4
result[0][0][2] = -4
result[0][0][3] = -1
result[0][0][4] = -1
result[0][0][5] = 0

# maddie
result[0][1][0] = -4
result[0][1][1] = -4
result[0][1][2] = -4
result[0][1][3] = -1
result[0][1][4] = -1
result[0][1][5] = 0

# colin
result[0][2][0] = -4
result[0][2][1] = -4
result[0][2][2] = -4
result[0][2][3] = -2
result[0][2][4] = -2
result[0][2][5] = 0.1
# romain
result[0][3][0] = -4
result[0][3][1] = -4
result[0][3][2] = -4
result[0][3][3] = -3
result[0][3][4] = -2
result[0][3][5] = 1

# jen
result[0][4][0] = -4
result[0][4][1] = -4
result[0][4][2] = -4
result[0][4][3] = -2.5
result[0][4][4] = -0.5
result[0][4][5] = -0.1

# speech -------------
# me
result[1][0][0] = -2
result[1][0][1] = -3
result[1][0][2] = -4
result[1][0][3] = -1
result[1][0][4] = -1
result[1][0][5] = 0

# maddie
result[1][1][0] = -3
result[1][1][1] = -4
result[1][1][2] = -4
result[1][1][3] = 0
result[1][1][4] = -1
result[1][1][5] = 0

# colin
result[1][2][0] = -4
result[1][2][1] = -4
result[1][2][2] = -4
result[1][2][3] = -2
result[1][2][4] = -2
result[1][2][5] = 0
# romain
result[1][3][0] = -4
result[1][3][1] = -4
result[1][3][2] = -4
result[1][3][3] = -2
result[1][3][4] = -2
result[1][3][5] = 0

# jen
result[1][4][0] = -3
result[1][4][1] = -4
result[1][4][2] = -3
result[1][4][3] = -2
result[1][4][4] = -2
result[1][4][5] = -0.1


# attack -------------
# me
result[2][0][0] = -3
result[2][0][1] = -4
result[2][0][2] = -4
result[2][0][3] = -1
result[2][0][4] = -1
result[2][0][5] = 0

# maddie
result[2][1][0] = -3
result[2][1][1] = -4
result[2][1][2] = -4
result[2][1][3] = 0
result[2][1][4] = 0
result[2][1][5] = 0

# colin
result[2][2][0] = -4
result[2][2][1] = -4
result[2][2][2] = -4
result[2][2][3] = -3
result[2][2][4] = -1
result[2][2][5] = 0
# romain
result[2][3][0] = -4
result[2][3][1] = -4
result[2][3][2] = -4
result[2][3][3] = -3
result[2][3][4] = -2
result[2][3][5] = 0

# jen
result[2][4][0] = -4
result[2][4][1] = -4
result[2][4][2] = -4
result[2][4][3] = -2
result[2][4][4] = -2
result[2][4][5] = -1

# for each coder
for i in range(3):
    average = np.zeros_like(result[0][1])
    highest = np.zeros_like(result[0][1]) - 5
    lowest = np.zeros_like(result[0][1]) + 5
    # for each person - average, highest, lowest
    for j in range(5):
        average += result[i][j]
        highest = np.maximum(highest,result[i][j])
        lowest = np.minimum(lowest,result[i][j])
    average /= 5
    print 'highest'
    print highest
    print 'lowest'
    print lowest
    print 'avg'
    print average
    # plot
    plt.figure()
    plt.title(tests[i])
    plt.plot(average,label = "average")
    plt.plot(highest, label = "highest")
    plt.plot(lowest, label = "lowest")
    plt.ylim([-5, 5])
    plt.xticks(range(len(coders)), coders, size='small')
    plt.legend()
    plt.show()


# for each coder
for i in range(3):
    average = np.zeros_like(result[0][1])
    highest = np.zeros_like(result[0][1]) - 5
    lowest = np.zeros_like(result[0][1]) + 5
    # for each non_experienced person - average, highest, lowest
    for j in range(len(non_experienced)):
        average += result[i][non_experienced[j]]
        highest = np.maximum(highest,result[i][non_experienced[j]])
        lowest = np.minimum(lowest,result[i][non_experienced[j]])
    average /= len(non_experienced)
    print 'highest'
    print highest
    print 'lowest'
    print lowest
    print 'avg'
    print average
    # plot
    plt.figure()
    plt.title('non-experienced' + tests[i])
    plt.plot(average,label = "average")
    plt.plot(highest, label = "highest")
    plt.plot(lowest, label = "lowest")
    plt.ylim([-5, 5])
    plt.xticks(range(len(coders)), coders, size='small')
    plt.legend()
    plt.show()

# for each coder
for i in range(3):
    average = np.zeros_like(result[0][1])
    highest = np.zeros_like(result[0][1]) - 5
    lowest = np.zeros_like(result[0][1]) + 5
    # for each experienced person - average, highest, lowest
    for j in range(len(experienced)):
        average += result[i][experienced[j]]
        highest = np.maximum(highest,result[i][experienced[j]])
        lowest = np.minimum(lowest,result[i][experienced[j]])
    average /= len(experienced)
    print 'highest'
    print highest
    print 'lowest'
    print lowest
    print 'avg'
    print average
    # plot
    plt.figure()
    plt.title('experienced' + tests[i])
    plt.plot(average,label = "average")
    plt.plot(highest, label = "highest")
    plt.plot(lowest, label = "lowest")
    plt.ylim([-5, 5])
    plt.xticks(range(len(coders)), coders, size='small')
    plt.legend()
    plt.show()

